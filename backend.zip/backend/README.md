# CampusGuide – Backend (ASP.NET Core 8)

Một project duy nhất `CampusGuide.Web` gồm **API cho app** (`/api/app/...`) và **trang Admin** (`/admin`).

```
backend/
├── CampusGuide.sln                  ← mở file này bằng Visual Studio 2022
└── CampusGuide.Web/
    ├── Models/                      ← 14 bảng CSDL (Thắng) + Dtos/ cho API
    ├── Data/                        ← AppDbContext, Migrations, DbSeeder, nhập CSV, Seed/*.csv (Thắng)
    ├── Services/                    ← dịch, TTS, TranslationPipeline, QR, ContentResolver, lưu file (Thắng)
    ├── Controllers/Api/AppApiController.cs   ← API cho app Flutter (Thắng)
    ├── Controllers/HomeController.cs         ← trang /q/{token} khi quét QR bằng camera thường
    └── Areas/Admin/
        ├── Controllers/  Account, Points, Translations, Languages, Glossary (Thắng)
        │                 Tours, OfflinePackages, Announcements, Stats  (Vương thêm vào đây)
        └── Views/        giao diện tương ứng (Bootstrap 5)
```

## Chạy lần đầu (Windows + Visual Studio 2022)

1. Cài **PostgreSQL 16** (có PostGIS: trong Stack Builder chọn *Spatial Extensions → PostGIS*) **hoặc** tạo CSDL miễn phí trên Neon/Supabase.
2. Copy `CampusGuide.Web/appsettings.Development.example.json` thành `appsettings.Development.json` (cùng thư mục) và sửa chuỗi kết nối. File này đã nằm trong `.gitignore`.
3. Mở `CampusGuide.sln` → chọn profile **CampusGuide.Web** → nhấn ▶. Lần chạy đầu tự tạo bảng và dữ liệu mẫu.
4. Trình duyệt mở `http://localhost:5000/admin`. Đăng nhập:
   - Quản trị viên: `admin@sgu.edu.vn` / `Admin@123`
   - Biên tập viên: `editor@sgu.edu.vn` / `Editor@123`

   Đổi mật khẩu ngay sau khi đưa lên máy chủ thật.

Dòng lệnh (macOS/Linux/Windows): `cd backend && dotnet run --project CampusGuide.Web`.
Tạo bảng thủ công thay vì để app tự làm: `dotnet tool install -g dotnet-ef` rồi `dotnet ef database update --project CampusGuide.Web`.

## Cấu hình (`appsettings.Development.json`)

| Khoá | Ý nghĩa | Để trống thì |
|---|---|---|
| `ConnectionStrings:Default` | PostgreSQL | bắt buộc |
| `GoogleCloud:ApiKey` | API key bật Cloud Translation + Text-to-Speech | dịch giả lập (`[EN] ...`), không sinh MP3; app và Admin đọc bằng giọng của thiết bị |
| `Storage:Url`, `Storage:Key`, `Storage:Bucket` | Supabase Storage (bucket public) để lưu ảnh, MP3 | lưu vào `wwwroot/media` trên máy chạy backend |
| `App:PublicBaseUrl` | địa chỉ in trong mã QR, ví dụ `https://campusguide.onrender.com` | lấy theo địa chỉ đang mở trang Admin |
| `App:CampusLatitude/Longitude/RadiusM` | tâm và bán kính khuôn viên, chặn nhập toạ độ sai | 10.7598, 106.6822, 1000 m |

> README chung của nhóm đang ghi `GoogleCloud:CredentialsPath` (file service account). Backend dùng **API key** cho đơn giản; nhớ sửa README chung cho khớp.

## Luồng nội dung đa ngôn ngữ

1. Biên tập viên lưu nội dung tiếng Việt của điểm → `TranslationPipeline.SaveSourceAsync` tính SHA-256, tăng `version`, đánh dấu bản dịch cũ `OUTDATED`, đưa vào hàng đợi.
2. `TranslationWorker` (chạy nền) dịch sang mọi ngôn ngữ đang bật. Thuật ngữ trong bảng `glossary_terms` được thay bằng cách viết chuẩn và giữ nguyên khi dịch. Kết quả `PENDING` (lỗi → `FAILED`).
3. Biên tập viên duyệt / sửa / từ chối ở **Bản dịch**. Duyệt thì sinh MP3 bằng Google TTS, cache theo SHA-256(văn bản + giọng + tốc độ) trong `audio_files`.
4. App gọi API, `ContentResolver` trả bản đã duyệt theo thứ tự: ngôn ngữ khách chọn → ngôn ngữ dự phòng → tiếng Việt.

API cho app: xem `docs/thang/API-APP.md` hoặc mở `http://localhost:5000/swagger`.
