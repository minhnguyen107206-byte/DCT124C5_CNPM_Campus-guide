Thư mục file tĩnh. Ảnh, MP3 khi chạy trên máy được lưu vào wwwroot/media (không đưa lên Git).
