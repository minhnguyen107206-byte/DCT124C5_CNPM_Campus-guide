using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Controllers;

public class HomeController(AppDbContext db, ContentResolver resolver) : Controller
{
    public IActionResult Index() => Redirect("/admin");

    /// <summary>
    /// Đích của đường dẫn in trong mã QR. Điện thoại đã cài app thì app tự xử lý token;
    /// quét bằng camera thường sẽ mở trang này để nghe ngay trên trình duyệt.
    /// </summary>
    [HttpGet("/q/{token}")]
    public async Task<IActionResult> Qr(string token, string? lang)
    {
        var point = await db.Points.AsNoTracking().FirstOrDefaultAsync(p => p.QrToken == token && p.Status == PointStatus.Active);
        if (point == null) return NotFound("Mã QR không hợp lệ hoặc điểm đã bị ẩn.");

        lang ??= Request.GetTypedHeaders().AcceptLanguage
            .OrderByDescending(x => x.Quality ?? 1).Select(x => x.Value.Value?.Split('-')[0]).FirstOrDefault();
        ViewBag.Languages = await db.Languages.AsNoTracking().Where(l => l.IsActive).OrderBy(l => l.Name).ToListAsync();
        ViewBag.Narration = await resolver.ResolveAsync(point.ContentId, lang);
        ViewBag.Lang = lang;
        return View(point);
    }

    [Route("/error")]
    public IActionResult Error() => Problem("Đã có lỗi xảy ra. Vui lòng thử lại.");
}
