using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Models.Dtos;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Controllers.Api;

/// <summary>
/// API cho app khách tham quan (không cần đăng nhập). Mọi endpoint nhận ?lang=en|zh|ko|ja|vi;
/// bỏ trống thì dùng tiếng Việt. Thử trực tiếp tại /swagger.
/// </summary>
[ApiController]
[Route("api/app")]
[Produces("application/json")]
public class AppApiController(AppDbContext db, ContentResolver resolver, Microsoft.Extensions.Options.IOptions<AppOptions> appOptions) : ControllerBase
{
    /// <summary>Danh sách ngôn ngữ đang bật (màn hình chọn ngôn ngữ).</summary>
    [HttpGet("languages")]
    public async Task<List<LanguageDto>> Languages(CancellationToken ct) =>
        await db.Languages.Where(l => l.IsActive)
            .OrderByDescending(l => l.Code == Language.SourceCode).ThenBy(l => l.Name)
            .Select(l => new LanguageDto(l.Code, l.Name, l.NativeName, l.IsFallback))
            .ToListAsync(ct);

    [HttpGet("categories")]
    public async Task<List<CategoryDto>> Categories(CancellationToken ct) =>
        await db.Categories.OrderBy(c => c.Id).Select(c => new CategoryDto(c.Id, c.Name, c.Icon)).ToListAsync(ct);

    /// <summary>
    /// Danh sách điểm cho bản đồ. q = tìm theo tên/mã; categoryId = lọc theo loại;
    /// lat/lng = vị trí hiện tại để tính khoảng cách và sắp xếp gần nhất trước.
    /// </summary>
    [HttpGet("points")]
    public async Task<List<PointSummaryDto>> PointList(string? q, int? categoryId, double? lat, double? lng, CancellationToken ct)
    {
        var query = db.Points.AsNoTracking().Include(p => p.Category).Where(p => p.Status == PointStatus.Active);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var pattern = $"%{q.Trim()}%";
            query = query.Where(p => EF.Functions.ILike(EF.Functions.Unaccent(p.Name), EF.Functions.Unaccent(pattern))
                                     || EF.Functions.ILike(p.Code, pattern));
        }
        if (categoryId != null) query = query.Where(p => p.CategoryId == categoryId);

        var points = await query.ToListAsync(ct);
        var here = lat != null && lng != null ? Point.MakeLocation(lat.Value, lng.Value) : null;
        return points
            .Select(p => ToSummary(p, here == null ? null : Geo.DistanceM(here, p.Location)))
            .OrderBy(p => p.DistanceM ?? 0).ThenBy(p => p.Code)
            .ToList();
    }

    [HttpGet("points/{id:long}")]
    public async Task<ActionResult<PointDetailDto>> PointDetail(long id, string? lang, CancellationToken ct)
    {
        var p = await db.Points.AsNoTracking().Include(x => x.Category)
            .FirstOrDefaultAsync(x => x.Id == id && x.Status == PointStatus.Active, ct);
        if (p == null) return NotFound();
        return await ToDetailAsync(p, lang, ct);
    }

    /// <summary>Quét QR: nhận token (hoặc cả đường dẫn .../q/{token}) và trả chi tiết điểm.</summary>
    [HttpGet("qr/{token}")]
    public async Task<ActionResult<PointDetailDto>> Qr(string token, string? lang, CancellationToken ct)
    {
        token = QrService.ExtractToken(token);
        var p = await db.Points.AsNoTracking().Include(x => x.Category)
            .FirstOrDefaultAsync(x => x.QrToken == token && x.Status == PointStatus.Active, ct);
        if (p == null) return NotFound(new { message = "Mã QR không hợp lệ hoặc điểm đã bị ẩn." });
        return await ToDetailAsync(p, lang, ct);
    }

    /// <summary>
    /// Geofence: các điểm mà vị trí (lat, lng) đang nằm trong bán kính kích hoạt,
    /// điểm ưu tiên cao rồi gần hơn đứng trước. App phát thuyết minh của phần tử đầu tiên.
    /// Gửi kèm deviceId thì bỏ các điểm thiết bị này vừa nghe (chống phát lặp, mặc định 30 phút).
    /// </summary>
    [HttpGet("nearby")]
    public async Task<List<PointSummaryDto>> Nearby(double lat, double lng, Guid? deviceId, CancellationToken ct)
    {
        var here = Point.MakeLocation(lat, lng);
        var since = DateTime.UtcNow.AddMinutes(-appOptions.Value.ReplayCooldownMinutes);
        var points = await db.Points.AsNoTracking().Include(p => p.Category)
            .Where(p => p.Status == PointStatus.Active && p.Location.IsWithinDistance(here, p.RadiusM))
            .Where(p => deviceId == null || !db.PlayLogs.Any(l => l.DeviceId == deviceId && l.PointId == p.Id && l.PlayedAt >= since))
            .ToListAsync(ct);
        return points
            .Select(p => ToSummary(p, Geo.DistanceM(here, p.Location)))
            .OrderByDescending(p => p.Priority).ThenBy(p => p.DistanceM)
            .ToList();
    }

    [HttpGet("tours")]
    public async Task<List<TourSummaryDto>> TourList(CancellationToken ct) =>
        await db.Tours.AsNoTracking().Where(t => t.Status == TourStatus.Published)
            .OrderBy(t => t.Name)
            .Select(t => new TourSummaryDto(t.Id, t.Name, t.EstimatedMinutes, t.DistanceM, t.Version, t.Stops.Count))
            .ToListAsync(ct);

    [HttpGet("tours/{id:long}")]
    public async Task<ActionResult<TourDetailDto>> TourDetail(long id, string? lang, CancellationToken ct)
    {
        var t = await db.Tours.AsNoTracking()
            .Include(x => x.Stops).ThenInclude(s => s.Point).ThenInclude(p => p!.Category)
            .FirstOrDefaultAsync(x => x.Id == id && x.Status == TourStatus.Published, ct);
        if (t == null) return NotFound();
        var desc = await resolver.ResolveAsync(t.ContentId, lang, ct);
        var stops = t.Stops.Where(s => s.Point!.Status == PointStatus.Active).OrderBy(s => s.StopOrder)
            .Select(s => new TourStopDto(s.StopOrder, ToSummary(s.Point!, null))).ToList();
        return new TourDetailDto(t.Id, t.Name, t.EstimatedMinutes, t.DistanceM, t.Version, ToNarration(desc), stops);
    }

    /// <summary>Thông báo đang hiệu lực. pointId = thông báo của khu vực đó và thông báo toàn trường.</summary>
    [HttpGet("announcements")]
    public async Task<List<AnnouncementDto>> Announcements(long? pointId, string? lang, CancellationToken ct)
    {
        var now = DateTime.UtcNow;
        var items = await db.Announcements.AsNoTracking()
            .Where(a => a.Status == AnnouncementStatus.Active && a.StartAt <= now && a.EndAt > now
                        && (pointId == null || a.PointId == null || a.PointId == pointId))
            .OrderByDescending(a => a.StartAt)
            .ToListAsync(ct);
        var bodies = await resolver.ResolveManyAsync(items.Select(a => a.ContentId), lang, ct);
        return items.Select(a => new AnnouncementDto(a.Id, a.Title, a.PointId, a.StartAt, a.EndAt,
            ToNarration(bodies.GetValueOrDefault(a.ContentId)))).ToList();
    }

    /// <summary>App gọi khi mở lần đầu hoặc đổi ngôn ngữ (thiết bị ẩn danh, id do app tự sinh).</summary>
    [HttpPost("devices")]
    public async Task<IActionResult> RegisterDevice(RegisterDeviceRequest req, CancellationToken ct)
    {
        if (!Enum.TryParse<DevicePlatform>(req.Platform, true, out var platform))
            return BadRequest(new { message = "platform phải là ANDROID, IOS hoặc WEB." });
        if (!await db.Languages.AnyAsync(l => l.Code == req.LanguageCode, ct))
            return BadRequest(new { message = "languageCode không tồn tại." });

        var device = await db.VisitorDevices.FindAsync([req.DeviceId], ct);
        if (device == null)
            db.VisitorDevices.Add(device = new VisitorDevice { Id = req.DeviceId });
        device.LanguageCode = req.LanguageCode;
        device.Platform = platform;
        device.AppVersion = req.AppVersion?.Length > 20 ? req.AppVersion[..20] : req.AppVersion;
        device.LastSeenAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    /// <summary>Ghi một lượt nghe (dùng cho thống kê). App gửi khi khách nghe xong hoặc dừng.</summary>
    [HttpPost("plays")]
    public async Task<IActionResult> LogPlay(PlayLogRequest req, CancellationToken ct)
    {
        if (!Enum.TryParse<TriggerType>(req.TriggerType, true, out var trigger))
            return BadRequest(new { message = "triggerType phải là GPS, QR, MANUAL hoặc OFFLINE." });
        if (!await db.VisitorDevices.AnyAsync(d => d.Id == req.DeviceId, ct))
            return BadRequest(new { message = "Thiết bị chưa đăng ký, gọi POST /api/app/devices trước." });
        if (!await db.Points.AnyAsync(p => p.Id == req.PointId, ct))
            return BadRequest(new { message = "pointId không tồn tại." });
        if (!await db.Languages.AnyAsync(l => l.Code == req.LanguageCode, ct))
            return BadRequest(new { message = "languageCode không tồn tại." });

        db.PlayLogs.Add(new PlayLog
        {
            DeviceId = req.DeviceId,
            PointId = req.PointId,
            LanguageCode = req.LanguageCode,
            TriggerType = trigger,
            ListenedMs = Math.Max(0, req.ListenedMs),
            // Lượt nghe offline gửi bù sau nên cho phép app gửi kèm thời điểm thật.
            PlayedAt = req.PlayedAt?.ToUniversalTime() ?? DateTime.UtcNow
        });
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    private async Task<PointDetailDto> ToDetailAsync(Point p, string? lang, CancellationToken ct)
    {
        var narration = await resolver.ResolveAsync(p.ContentId, lang, ct);
        return new PointDetailDto(p.Id, p.Code, p.Name, p.CategoryId, p.Category?.Name, p.Category?.Icon,
            p.Latitude, p.Longitude, p.RadiusM, p.Priority, p.FloorInfo, p.OpeningHours,
            AbsoluteUrl(p.ImageUrl), ToNarration(narration));
    }

    private PointSummaryDto ToSummary(Point p, double? distance) =>
        new(p.Id, p.Code, p.Name, p.CategoryId, p.Category?.Name, p.Category?.Icon,
            p.Latitude, p.Longitude, p.RadiusM, p.Priority, AbsoluteUrl(p.ImageUrl),
            distance == null ? null : Math.Round(distance.Value, 1));

    private NarrationDto ToNarration(ResolvedContent? c) => c == null
        ? new NarrationDto(Language.SourceCode, "", null, null, false)
        : new NarrationDto(c.LanguageCode, c.Text, AbsoluteUrl(c.AudioUrl), c.DurationMs, c.IsFallback);

    /// <summary>Đổi "/media/..." thành URL đầy đủ theo địa chỉ app đang gọi (10.0.2.2, IP LAN, ...).</summary>
    private string? AbsoluteUrl(string? url) =>
        string.IsNullOrEmpty(url) || url.StartsWith("http", StringComparison.OrdinalIgnoreCase)
            ? url
            : $"{Request.Scheme}://{Request.Host}{url}";
}
