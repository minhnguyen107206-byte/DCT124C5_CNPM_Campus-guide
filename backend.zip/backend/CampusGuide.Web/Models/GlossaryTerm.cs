namespace CampusGuide.Web.Models;

/// <summary>Bảng glossary_terms: thuật ngữ, tên riêng cần dịch thống nhất.</summary>
public class GlossaryTerm
{
    public long Id { get; set; }
    public string SourceTerm { get; set; } = "";
    public string LanguageCode { get; set; } = "";
    public string TargetTerm { get; set; } = "";
    public string? Note { get; set; }

    public Language? Language { get; set; }
}
