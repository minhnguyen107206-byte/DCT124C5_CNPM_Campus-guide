namespace CampusGuide.Web.Models;

/// <summary>Bảng points: điểm thuyết minh trong khuôn viên.</summary>
public class Point
{
    public long Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public int CategoryId { get; set; }
    public long ContentId { get; set; }

    /// <summary>geography(Point, 4326). X = kinh độ, Y = vĩ độ.</summary>
    public NetTopologySuite.Geometries.Point Location { get; set; } = null!;

    public short RadiusM { get; set; } = 30;
    public short Priority { get; set; }
    public string? FloorInfo { get; set; }
    public string? OpeningHours { get; set; }

    /// <summary>Ảnh đại diện của điểm (cột thêm so với báo cáo, xem docs/thang/DOI-CHIEU-CHUONG-4.md).</summary>
    public string? ImageUrl { get; set; }

    public string QrToken { get; set; } = "";
    public PointStatus Status { get; set; } = PointStatus.Active;
    public long? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public Category? Category { get; set; }
    public Content? Content { get; set; }
    public User? CreatedByUser { get; set; }

    public double Latitude => Location.Y;
    public double Longitude => Location.X;

    public static NetTopologySuite.Geometries.Point MakeLocation(double lat, double lng) =>
        new(lng, lat) { SRID = 4326 };
}
