namespace CampusGuide.Web.Models;

// Giá trị lưu trong CSDL là chữ in hoa (ADMIN, EDITOR, ...) đúng như bảng mô tả chi tiết của báo cáo.

public enum UserRole { Admin, Editor }

public enum UserStatus { Active, Locked }

public enum PointStatus { Active, Hidden }

public enum TranslationMethod { Machine, Human }

public enum TranslationStatus { Pending, Approved, Rejected, Outdated, Failed }

public enum TourStatus { Draft, Published, Hidden }

public enum AnnouncementStatus { Active, Removed }

public enum DevicePlatform { Android, Ios, Web }

public enum TriggerType { Gps, Qr, Manual, Offline }
