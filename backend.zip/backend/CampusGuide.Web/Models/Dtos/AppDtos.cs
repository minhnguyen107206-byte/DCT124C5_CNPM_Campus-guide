namespace CampusGuide.Web.Models.Dtos;

// Dữ liệu trả cho app Flutter (JSON camelCase). Xem thêm docs/API-APP.md.

public record LanguageDto(string Code, string Name, string NativeName, bool IsFallback);

public record CategoryDto(int Id, string Name, string? Icon);

/// <summary>Một điểm trong danh sách/bản đồ (không kèm văn bản thuyết minh để nhẹ).</summary>
public record PointSummaryDto(
    long Id, string Code, string Name, int CategoryId, string? CategoryName, string? CategoryIcon,
    double Latitude, double Longitude, int RadiusM, int Priority, string? ImageUrl, double? DistanceM);

/// <summary>Chi tiết điểm kèm bản thuyết minh theo ngôn ngữ đã chọn.</summary>
public record PointDetailDto(
    long Id, string Code, string Name, int CategoryId, string? CategoryName, string? CategoryIcon,
    double Latitude, double Longitude, int RadiusM, int Priority, string? FloorInfo, string? OpeningHours,
    string? ImageUrl, NarrationDto Narration);

/// <summary>
/// Bản thuyết minh. AudioUrl null thì app đọc Text bằng giọng của thiết bị (flutter_tts) theo LanguageCode.
/// IsFallback = true nghĩa là chưa có bản đã duyệt cho ngôn ngữ khách chọn, đang dùng ngôn ngữ dự phòng.
/// </summary>
public record NarrationDto(string LanguageCode, string Text, string? AudioUrl, int? DurationMs, bool IsFallback);

public record TourSummaryDto(long Id, string Name, int EstimatedMinutes, int DistanceM, int Version, int StopCount);

public record TourStopDto(int StopOrder, PointSummaryDto Point);

public record TourDetailDto(long Id, string Name, int EstimatedMinutes, int DistanceM, int Version,
    NarrationDto Description, List<TourStopDto> Stops);

public record AnnouncementDto(long Id, string Title, long? PointId, DateTime StartAt, DateTime EndAt, NarrationDto Body);

public record RegisterDeviceRequest(Guid DeviceId, string LanguageCode, string Platform, string? AppVersion);

public record PlayLogRequest(Guid DeviceId, long PointId, string LanguageCode, string TriggerType, int ListenedMs, DateTime? PlayedAt);
