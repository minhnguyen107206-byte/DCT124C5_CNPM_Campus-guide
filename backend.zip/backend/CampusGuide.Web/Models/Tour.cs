namespace CampusGuide.Web.Models;

/// <summary>Bảng tours: tour tham quan gợi ý.</summary>
public class Tour
{
    public long Id { get; set; }
    public string Name { get; set; } = "";
    public long ContentId { get; set; }
    public short EstimatedMinutes { get; set; }
    public int DistanceM { get; set; }
    public TourStatus Status { get; set; } = TourStatus.Draft;
    public int Version { get; set; } = 1;
    public long? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Content? Content { get; set; }
    public List<TourStop> Stops { get; set; } = new();
}

/// <summary>Bảng tour_stops: điểm dừng của tour (M:N giữa tours và points).</summary>
public class TourStop
{
    public long TourId { get; set; }
    public long PointId { get; set; }
    public short StopOrder { get; set; }

    public Tour? Tour { get; set; }
    public Point? Point { get; set; }
}
