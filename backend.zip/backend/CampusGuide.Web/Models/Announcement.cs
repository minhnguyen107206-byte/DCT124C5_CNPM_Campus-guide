namespace CampusGuide.Web.Models;

/// <summary>Bảng announcements: thông báo theo khu vực. PointId null nghĩa là toàn trường.</summary>
public class Announcement
{
    public long Id { get; set; }
    public string Title { get; set; } = "";
    public long ContentId { get; set; }
    public long? PointId { get; set; }
    public DateTime StartAt { get; set; }
    public DateTime EndAt { get; set; }
    public AnnouncementStatus Status { get; set; } = AnnouncementStatus.Active;
    public long? CreatedBy { get; set; }

    public Content? Content { get; set; }
    public Point? Point { get; set; }
}
