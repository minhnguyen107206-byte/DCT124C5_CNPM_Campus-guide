namespace CampusGuide.Web.Models;

/// <summary>Bảng categories: loại điểm thuyết minh.</summary>
public class Category
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string? Icon { get; set; }
}
