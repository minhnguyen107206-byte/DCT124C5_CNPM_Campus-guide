namespace CampusGuide.Web.Models;

/// <summary>Bảng languages: ngôn ngữ hệ thống hỗ trợ, khoá chính là mã ISO 639-1.</summary>
public class Language
{
    /// <summary>Ngôn ngữ của nội dung gốc.</summary>
    public const string SourceCode = "vi";

    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string NativeName { get; set; } = "";
    public string TtsVoice { get; set; } = "";
    public decimal TtsSpeed { get; set; } = 1.00m;
    public bool IsActive { get; set; } = true;
    public bool IsFallback { get; set; }
}
