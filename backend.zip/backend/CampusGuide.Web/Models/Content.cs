namespace CampusGuide.Web.Models;

/// <summary>Bảng contents: nội dung gốc tiếng Việt, dùng chung cho điểm, tour và thông báo.</summary>
public class Content
{
    public const int MaxLength = 3000;

    public long Id { get; set; }
    public string SourceText { get; set; } = "";
    public string ContentHash { get; set; } = "";
    public int Version { get; set; } = 1;
    public long? UpdatedBy { get; set; }
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public User? UpdatedByUser { get; set; }
    public List<Translation> Translations { get; set; } = new();
}
