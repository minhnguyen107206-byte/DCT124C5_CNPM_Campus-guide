namespace CampusGuide.Web.Models;

/// <summary>Bảng offline_packages: gói tải trước của tour theo ngôn ngữ.</summary>
public class OfflinePackage
{
    public long Id { get; set; }
    public long TourId { get; set; }
    public string LanguageCode { get; set; } = "";
    public int TourVersion { get; set; }
    public string FileUrl { get; set; } = "";
    public long SizeBytes { get; set; }
    public string Checksum { get; set; } = "";
    public DateTime BuiltAt { get; set; } = DateTime.UtcNow;

    public Tour? Tour { get; set; }
}
