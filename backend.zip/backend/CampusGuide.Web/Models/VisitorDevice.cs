namespace CampusGuide.Web.Models;

/// <summary>Bảng visitor_devices: thiết bị khách (ẩn danh, id do app sinh).</summary>
public class VisitorDevice
{
    public Guid Id { get; set; }
    public string LanguageCode { get; set; } = Language.SourceCode;
    public DevicePlatform Platform { get; set; }
    public string? AppVersion { get; set; }
    public DateTime FirstSeenAt { get; set; } = DateTime.UtcNow;
    public DateTime LastSeenAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Bảng play_logs: lượt nghe thuyết minh.</summary>
public class PlayLog
{
    public long Id { get; set; }
    public Guid DeviceId { get; set; }
    public long PointId { get; set; }
    public string LanguageCode { get; set; } = "";
    public TriggerType TriggerType { get; set; }
    public DateTime PlayedAt { get; set; } = DateTime.UtcNow;
    public int ListenedMs { get; set; }

    public VisitorDevice? Device { get; set; }
    public Point? Point { get; set; }
}
