namespace CampusGuide.Web.Models;

/// <summary>Bảng audio_files: file MP3 sinh bằng TTS, cache theo SHA-256(văn bản + giọng + tốc độ).</summary>
public class AudioFile
{
    public long Id { get; set; }
    public string TextHash { get; set; } = "";
    public string Voice { get; set; } = "";
    public decimal Speed { get; set; } = 1.00m;
    public string FileUrl { get; set; } = "";
    public int DurationMs { get; set; }
    public int SizeBytes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
