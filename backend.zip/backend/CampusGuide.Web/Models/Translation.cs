namespace CampusGuide.Web.Models;

/// <summary>Bảng translations: bản dịch của một nội dung sang một ngôn ngữ.</summary>
public class Translation
{
    public long Id { get; set; }
    public long ContentId { get; set; }
    public string LanguageCode { get; set; } = "";
    public string? TranslatedText { get; set; }
    public string? SourceHash { get; set; }
    public TranslationMethod Method { get; set; } = TranslationMethod.Machine;
    public TranslationStatus Status { get; set; } = TranslationStatus.Pending;
    public long? AudioId { get; set; }
    public long? ReviewedBy { get; set; }
    public DateTime? ReviewedAt { get; set; }
    public string? RejectReason { get; set; }

    public Content? Content { get; set; }
    public Language? Language { get; set; }
    public AudioFile? Audio { get; set; }
    public User? ReviewedByUser { get; set; }
}
