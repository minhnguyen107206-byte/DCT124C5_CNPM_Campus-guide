﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using NetTopologySuite.Geometries;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace CampusGuide.Web.Data.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("Npgsql:PostgresExtension:postgis", ",,")
                .Annotation("Npgsql:PostgresExtension:unaccent", ",,");

            migrationBuilder.CreateTable(
                name: "audio_files",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    text_hash = table.Column<string>(type: "character(64)", fixedLength: true, maxLength: 64, nullable: false),
                    voice = table.Column<string>(type: "character varying(60)", maxLength: 60, nullable: false),
                    speed = table.Column<decimal>(type: "numeric(3,2)", precision: 3, scale: 2, nullable: false),
                    file_url = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    duration_ms = table.Column<int>(type: "integer", nullable: false),
                    size_bytes = table.Column<int>(type: "integer", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_audio_files", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "categories",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "character varying(60)", maxLength: 60, nullable: false),
                    icon = table.Column<string>(type: "character varying(40)", maxLength: 40, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_categories", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "languages",
                columns: table => new
                {
                    code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    name = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    native_name = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    tts_voice = table.Column<string>(type: "character varying(60)", maxLength: 60, nullable: false),
                    tts_speed = table.Column<decimal>(type: "numeric(3,2)", precision: 3, scale: 2, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    is_fallback = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_languages", x => x.code);
                });

            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    full_name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    email = table.Column<string>(type: "character varying(120)", maxLength: 120, nullable: false),
                    password_hash = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    role = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    status = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    last_login_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "glossary_terms",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    source_term = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    language_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    target_term = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    note = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_glossary_terms", x => x.id);
                    table.ForeignKey(
                        name: "fk_glossary_terms_languages_language_code",
                        column: x => x.language_code,
                        principalTable: "languages",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "visitor_devices",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uuid", nullable: false),
                    language_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    platform = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    app_version = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: true),
                    first_seen_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    last_seen_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_visitor_devices", x => x.id);
                    table.ForeignKey(
                        name: "fk_visitor_devices_languages_language_code",
                        column: x => x.language_code,
                        principalTable: "languages",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "contents",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    source_text = table.Column<string>(type: "text", nullable: false),
                    content_hash = table.Column<string>(type: "character(64)", fixedLength: true, maxLength: 64, nullable: false),
                    version = table.Column<int>(type: "integer", nullable: false),
                    updated_by = table.Column<long>(type: "bigint", nullable: true),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_contents", x => x.id);
                    table.ForeignKey(
                        name: "fk_contents_users_updated_by",
                        column: x => x.updated_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "points",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    code = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    name = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    category_id = table.Column<int>(type: "integer", nullable: false),
                    content_id = table.Column<long>(type: "bigint", nullable: false),
                    location = table.Column<Point>(type: "geography(Point,4326)", nullable: false),
                    radius_m = table.Column<short>(type: "smallint", nullable: false),
                    priority = table.Column<short>(type: "smallint", nullable: false),
                    floor_info = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    opening_hours = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    image_url = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true),
                    qr_token = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                    status = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    created_by = table.Column<long>(type: "bigint", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_points", x => x.id);
                    table.CheckConstraint("ck_points_radius", "radius_m BETWEEN 10 AND 200");
                    table.ForeignKey(
                        name: "fk_points_categories_category_id",
                        column: x => x.category_id,
                        principalTable: "categories",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_points_contents_content_id",
                        column: x => x.content_id,
                        principalTable: "contents",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_points_users_created_by",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "tours",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    content_id = table.Column<long>(type: "bigint", nullable: false),
                    estimated_minutes = table.Column<short>(type: "smallint", nullable: false),
                    distance_m = table.Column<int>(type: "integer", nullable: false),
                    status = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    version = table.Column<int>(type: "integer", nullable: false),
                    created_by = table.Column<long>(type: "bigint", nullable: true),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tours", x => x.id);
                    table.ForeignKey(
                        name: "fk_tours_contents_content_id",
                        column: x => x.content_id,
                        principalTable: "contents",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_tours_users_created_by",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "translations",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    content_id = table.Column<long>(type: "bigint", nullable: false),
                    language_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    translated_text = table.Column<string>(type: "text", nullable: true),
                    source_hash = table.Column<string>(type: "character(64)", fixedLength: true, maxLength: 64, nullable: true),
                    method = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    status = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    audio_id = table.Column<long>(type: "bigint", nullable: true),
                    reviewed_by = table.Column<long>(type: "bigint", nullable: true),
                    reviewed_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    reject_reason = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_translations", x => x.id);
                    table.ForeignKey(
                        name: "fk_translations_audio_files_audio_id",
                        column: x => x.audio_id,
                        principalTable: "audio_files",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "fk_translations_contents_content_id",
                        column: x => x.content_id,
                        principalTable: "contents",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_translations_languages_language_code",
                        column: x => x.language_code,
                        principalTable: "languages",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_translations_users_reviewed_by",
                        column: x => x.reviewed_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "announcements",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    title = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    content_id = table.Column<long>(type: "bigint", nullable: false),
                    point_id = table.Column<long>(type: "bigint", nullable: true),
                    start_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    end_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    status = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    created_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_announcements", x => x.id);
                    table.CheckConstraint("ck_announcements_time", "start_at < end_at");
                    table.ForeignKey(
                        name: "fk_announcements_contents_content_id",
                        column: x => x.content_id,
                        principalTable: "contents",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_announcements_points_point_id",
                        column: x => x.point_id,
                        principalTable: "points",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "fk_announcements_users_created_by",
                        column: x => x.created_by,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "play_logs",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    device_id = table.Column<Guid>(type: "uuid", nullable: false),
                    point_id = table.Column<long>(type: "bigint", nullable: false),
                    language_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    trigger_type = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    played_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    listened_ms = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_play_logs", x => x.id);
                    table.ForeignKey(
                        name: "fk_play_logs_languages_language_code",
                        column: x => x.language_code,
                        principalTable: "languages",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_play_logs_points_point_id",
                        column: x => x.point_id,
                        principalTable: "points",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_play_logs_visitor_devices_device_id",
                        column: x => x.device_id,
                        principalTable: "visitor_devices",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "offline_packages",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    tour_id = table.Column<long>(type: "bigint", nullable: false),
                    language_code = table.Column<string>(type: "character varying(10)", maxLength: 10, nullable: false),
                    tour_version = table.Column<int>(type: "integer", nullable: false),
                    file_url = table.Column<string>(type: "character varying(255)", maxLength: 255, nullable: false),
                    size_bytes = table.Column<long>(type: "bigint", nullable: false),
                    checksum = table.Column<string>(type: "character(64)", fixedLength: true, maxLength: 64, nullable: false),
                    built_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_offline_packages", x => x.id);
                    table.ForeignKey(
                        name: "fk_offline_packages_languages_language_code",
                        column: x => x.language_code,
                        principalTable: "languages",
                        principalColumn: "code",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_offline_packages_tours_tour_id",
                        column: x => x.tour_id,
                        principalTable: "tours",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tour_stops",
                columns: table => new
                {
                    tour_id = table.Column<long>(type: "bigint", nullable: false),
                    point_id = table.Column<long>(type: "bigint", nullable: false),
                    stop_order = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tour_stops", x => new { x.tour_id, x.point_id });
                    table.ForeignKey(
                        name: "fk_tour_stops_points_point_id",
                        column: x => x.point_id,
                        principalTable: "points",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_tour_stops_tours_tour_id",
                        column: x => x.tour_id,
                        principalTable: "tours",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_announcements_content_id",
                table: "announcements",
                column: "content_id");

            migrationBuilder.CreateIndex(
                name: "ix_announcements_created_by",
                table: "announcements",
                column: "created_by");

            migrationBuilder.CreateIndex(
                name: "ix_announcements_point_id",
                table: "announcements",
                column: "point_id");

            migrationBuilder.CreateIndex(
                name: "ix_audio_files_text_hash",
                table: "audio_files",
                column: "text_hash",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_contents_updated_by",
                table: "contents",
                column: "updated_by");

            migrationBuilder.CreateIndex(
                name: "ix_glossary_terms_language_code",
                table: "glossary_terms",
                column: "language_code");

            migrationBuilder.CreateIndex(
                name: "ix_glossary_terms_source_term_language_code",
                table: "glossary_terms",
                columns: new[] { "source_term", "language_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_languages_is_fallback",
                table: "languages",
                column: "is_fallback",
                unique: true,
                filter: "is_fallback");

            migrationBuilder.CreateIndex(
                name: "ix_offline_packages_language_code",
                table: "offline_packages",
                column: "language_code");

            migrationBuilder.CreateIndex(
                name: "ix_offline_packages_tour_id_language_code_tour_version",
                table: "offline_packages",
                columns: new[] { "tour_id", "language_code", "tour_version" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_play_logs_device_id_point_id_played_at",
                table: "play_logs",
                columns: new[] { "device_id", "point_id", "played_at" },
                descending: new[] { false, false, true });

            migrationBuilder.CreateIndex(
                name: "ix_play_logs_language_code",
                table: "play_logs",
                column: "language_code");

            migrationBuilder.CreateIndex(
                name: "ix_play_logs_played_at",
                table: "play_logs",
                column: "played_at");

            migrationBuilder.CreateIndex(
                name: "ix_play_logs_point_id",
                table: "play_logs",
                column: "point_id");

            migrationBuilder.CreateIndex(
                name: "ix_points_category_id",
                table: "points",
                column: "category_id");

            migrationBuilder.CreateIndex(
                name: "ix_points_code",
                table: "points",
                column: "code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_points_content_id",
                table: "points",
                column: "content_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_points_created_by",
                table: "points",
                column: "created_by");

            migrationBuilder.CreateIndex(
                name: "ix_points_location",
                table: "points",
                column: "location")
                .Annotation("Npgsql:IndexMethod", "gist");

            migrationBuilder.CreateIndex(
                name: "ix_points_qr_token",
                table: "points",
                column: "qr_token",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_tour_stops_point_id",
                table: "tour_stops",
                column: "point_id");

            migrationBuilder.CreateIndex(
                name: "ix_tour_stops_tour_id_stop_order",
                table: "tour_stops",
                columns: new[] { "tour_id", "stop_order" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_tours_content_id",
                table: "tours",
                column: "content_id");

            migrationBuilder.CreateIndex(
                name: "ix_tours_created_by",
                table: "tours",
                column: "created_by");

            migrationBuilder.CreateIndex(
                name: "ix_translations_audio_id",
                table: "translations",
                column: "audio_id");

            migrationBuilder.CreateIndex(
                name: "ix_translations_content_id_language_code",
                table: "translations",
                columns: new[] { "content_id", "language_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_translations_language_code",
                table: "translations",
                column: "language_code");

            migrationBuilder.CreateIndex(
                name: "ix_translations_reviewed_by",
                table: "translations",
                column: "reviewed_by");

            migrationBuilder.CreateIndex(
                name: "ix_translations_status_language_code",
                table: "translations",
                columns: new[] { "status", "language_code" });

            migrationBuilder.CreateIndex(
                name: "ix_users_email",
                table: "users",
                column: "email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_visitor_devices_language_code",
                table: "visitor_devices",
                column: "language_code");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "announcements");

            migrationBuilder.DropTable(
                name: "glossary_terms");

            migrationBuilder.DropTable(
                name: "offline_packages");

            migrationBuilder.DropTable(
                name: "play_logs");

            migrationBuilder.DropTable(
                name: "tour_stops");

            migrationBuilder.DropTable(
                name: "translations");

            migrationBuilder.DropTable(
                name: "visitor_devices");

            migrationBuilder.DropTable(
                name: "points");

            migrationBuilder.DropTable(
                name: "tours");

            migrationBuilder.DropTable(
                name: "audio_files");

            migrationBuilder.DropTable(
                name: "languages");

            migrationBuilder.DropTable(
                name: "categories");

            migrationBuilder.DropTable(
                name: "contents");

            migrationBuilder.DropTable(
                name: "users");
        }
    }
}
