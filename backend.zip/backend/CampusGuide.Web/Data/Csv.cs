using System.Text;

namespace CampusGuide.Web.Data;

/// <summary>Đọc CSV (RFC 4180: có ngoặc kép, xuống dòng trong ô). Tự nhận dấu phân cách ',' hoặc ';' (Excel bản tiếng Việt hay lưu ';').</summary>
public static class Csv
{
    public static List<Dictionary<string, string>> Read(string text)
    {
        text = text.TrimStart('﻿');
        var firstLine = text.Split('\n', 2)[0];
        var sep = firstLine.Count(c => c == ';') > firstLine.Count(c => c == ',') ? ';' : ',';
        var rows = ParseRows(text, sep);
        if (rows.Count == 0) return new();

        var header = rows[0].Select(h => h.Trim().ToLowerInvariant()).ToList();
        var result = new List<Dictionary<string, string>>();
        foreach (var row in rows.Skip(1))
        {
            if (row.All(string.IsNullOrWhiteSpace)) continue;
            var dict = new Dictionary<string, string>();
            for (var i = 0; i < header.Count; i++)
                dict[header[i]] = i < row.Count ? row[i].Trim() : "";
            result.Add(dict);
        }
        return result;
    }

    private static List<List<string>> ParseRows(string text, char sep)
    {
        var rows = new List<List<string>>();
        var row = new List<string>();
        var cell = new StringBuilder();
        var quoted = false;
        for (var i = 0; i < text.Length; i++)
        {
            var c = text[i];
            if (quoted)
            {
                if (c == '"' && i + 1 < text.Length && text[i + 1] == '"') { cell.Append('"'); i++; }
                else if (c == '"') quoted = false;
                else cell.Append(c);
            }
            else if (c == '"') quoted = true;
            else if (c == sep) { row.Add(cell.ToString()); cell.Clear(); }
            else if (c == '\n')
            {
                row.Add(cell.ToString().TrimEnd('\r')); cell.Clear();
                rows.Add(row); row = new List<string>();
            }
            else cell.Append(c);
        }
        if (cell.Length > 0 || row.Count > 0) { row.Add(cell.ToString().TrimEnd('\r')); rows.Add(row); }
        return rows;
    }

    public static string Get(this Dictionary<string, string> row, string key) =>
        row.TryGetValue(key, out var v) ? v : "";
}
