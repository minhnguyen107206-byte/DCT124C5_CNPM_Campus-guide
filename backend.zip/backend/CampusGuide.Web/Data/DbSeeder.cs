using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Data;

/// <summary>
/// Dữ liệu mẫu khi CSDL còn trống: 2 tài khoản, 5 ngôn ngữ, loại điểm, thuật ngữ của trường
/// (Data/Seed/thuat-ngu.csv) và 8 điểm mẫu (Data/Seed/diem.csv, toạ độ gần đúng, cần đo lại).
/// Chạy lại nhiều lần không sao: phần nào đã có dữ liệu thì bỏ qua.
/// </summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services, CancellationToken ct = default)
    {
        var db = services.GetRequiredService<AppDbContext>();
        var importer = services.GetRequiredService<DataImporter>();
        var log = services.GetRequiredService<ILoggerFactory>().CreateLogger("DbSeeder");
        var seedDir = Path.Combine(AppContext.BaseDirectory, "Data", "Seed");

        if (!await db.Users.AnyAsync(ct))
        {
            db.Users.AddRange(
                new User { FullName = "Quản trị viên", Email = "admin@sgu.edu.vn", PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@123"), Role = UserRole.Admin },
                new User { FullName = "Biên tập viên", Email = "editor@sgu.edu.vn", PasswordHash = BCrypt.Net.BCrypt.HashPassword("Editor@123"), Role = UserRole.Editor });
            await db.SaveChangesAsync(ct);
            log.LogInformation("Đã tạo tài khoản mẫu admin@sgu.edu.vn / Admin@123 và editor@sgu.edu.vn / Editor@123");
        }

        if (!await db.Languages.AnyAsync(ct))
        {
            // Giọng Standard nằm trong hạn mức miễn phí lớn nhất của Google TTS (4 triệu ký tự/tháng).
            db.Languages.AddRange(
                new Language { Code = "vi", Name = "Tiếng Việt", NativeName = "Tiếng Việt", TtsVoice = "vi-VN-Standard-A", TtsSpeed = 1.00m },
                new Language { Code = "en", Name = "Tiếng Anh", NativeName = "English", TtsVoice = "en-US-Standard-C", TtsSpeed = 1.00m, IsFallback = true },
                new Language { Code = "zh", Name = "Tiếng Trung", NativeName = "中文", TtsVoice = "cmn-CN-Standard-A", TtsSpeed = 1.00m },
                new Language { Code = "ko", Name = "Tiếng Hàn", NativeName = "한국어", TtsVoice = "ko-KR-Standard-A", TtsSpeed = 1.00m },
                new Language { Code = "ja", Name = "Tiếng Nhật", NativeName = "日本語", TtsVoice = "ja-JP-Standard-A", TtsSpeed = 1.00m });
            await db.SaveChangesAsync(ct);
        }

        if (!await db.Categories.AnyAsync(ct))
        {
            // Icon là tên Material Icons để app Flutter dùng trực tiếp (Icons.school, ...).
            db.Categories.AddRange(
                new Category { Name = "Cổng", Icon = "door_front" },
                new Category { Name = "Toà nhà học", Icon = "school" },
                new Category { Name = "Thư viện", Icon = "local_library" },
                new Category { Name = "Phòng ban", Icon = "business" },
                new Category { Name = "Hội trường", Icon = "groups" },
                new Category { Name = "Căng tin", Icon = "restaurant" },
                new Category { Name = "Sân thể thao", Icon = "sports_soccer" },
                new Category { Name = "Bãi giữ xe", Icon = "local_parking" },
                new Category { Name = "Ký túc xá", Icon = "hotel" });
            await db.SaveChangesAsync(ct);
        }

        var glossaryFile = Path.Combine(seedDir, "thuat-ngu.csv");
        if (!await db.GlossaryTerms.AnyAsync(ct) && File.Exists(glossaryFile))
        {
            var r = await importer.ImportGlossaryAsync(await File.ReadAllTextAsync(glossaryFile, ct), ct);
            log.LogInformation("Đã nhập {Count} thuật ngữ mẫu", r.Added);
        }

        var pointsFile = Path.Combine(seedDir, "diem.csv");
        if (!await db.Points.AnyAsync(ct) && File.Exists(pointsFile))
        {
            var adminId = await db.Users.Where(u => u.Role == UserRole.Admin).Select(u => (long?)u.Id).FirstOrDefaultAsync(ct);
            var r = await importer.ImportPointsAsync(await File.ReadAllTextAsync(pointsFile, ct), adminId, ct);
            log.LogInformation("Đã nhập {Count} điểm mẫu (bản dịch đang được tạo nền)", r.Added);
            foreach (var e in r.Errors) log.LogWarning("{Error}", e);
        }
    }
}
