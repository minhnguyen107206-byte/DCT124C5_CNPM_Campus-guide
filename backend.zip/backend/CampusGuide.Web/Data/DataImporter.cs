using System.Globalization;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Data;

/// <summary>Kết quả nhập CSV để hiện lên trang Admin.</summary>
public record ImportResult(int Added, int Updated, List<string> Errors);

/// <summary>
/// Nhập điểm và thuật ngữ từ CSV (mẫu ở docs/mau-nhap-diem.csv và Data/Seed/thuat-ngu.csv).
/// Điểm được ghép theo cột "ma": có rồi thì cập nhật, chưa có thì thêm mới.
/// </summary>
public class DataImporter(AppDbContext db, TranslationPipeline pipeline, Microsoft.Extensions.Options.IOptions<AppOptions> appOptions)
{
    // Cột: ma, ten, loai, vi_do, kinh_do, ban_kinh_m, uu_tien, tang_phong, gio_mo_cua, anh, noi_dung
    public async Task<ImportResult> ImportPointsAsync(string csv, long? userId, CancellationToken ct = default)
    {
        var errors = new List<string>();
        int added = 0, updated = 0, line = 1;
        var categories = await db.Categories.ToListAsync(ct);

        foreach (var row in Csv.Read(csv))
        {
            line++;
            var code = row.Get("ma");
            var name = row.Get("ten");
            var text = row.Get("noi_dung");
            if (code == "" || name == "")
            {
                errors.Add($"Dòng {line}: thiếu mã hoặc tên điểm.");
                continue;
            }
            if (!TryNumber(row.Get("vi_do"), out var lat) || !TryNumber(row.Get("kinh_do"), out var lng)
                || lat is < -90 or > 90 || lng is < -180 or > 180)
            {
                errors.Add($"Dòng {line} ({code}): vĩ độ/kinh độ không hợp lệ.");
                continue;
            }
            if (!appOptions.Value.IsInsideCampus(lat, lng))
            {
                errors.Add($"Dòng {line} ({code}): toạ độ {lat}, {lng} nằm ngoài khuôn viên (có thể bị đảo vĩ độ/kinh độ).");
                continue;
            }
            if (text == "")
            {
                errors.Add($"Dòng {line} ({code}): chưa có nội dung thuyết minh.");
                continue;
            }

            var catName = row.Get("loai");
            if (catName == "") catName = "Khác";
            var category = categories.FirstOrDefault(c => string.Equals(c.Name, catName, StringComparison.OrdinalIgnoreCase));
            if (category == null)
            {
                category = new Category { Name = catName, Icon = "place" };
                db.Categories.Add(category);
                categories.Add(category);
                await db.SaveChangesAsync(ct);
            }

            var radius = TryNumber(row.Get("ban_kinh_m"), out var r) ? (short)Math.Clamp(r, 10, 200) : (short)30;
            var priority = TryNumber(row.Get("uu_tien"), out var p) ? (short)p : (short)0;

            var point = await db.Points.Include(x => x.Content).FirstOrDefaultAsync(x => x.Code == code, ct);
            try
            {
                if (point == null)
                {
                    var content = await pipeline.SaveSourceAsync(null, text, userId, ct);
                    point = new Point
                    {
                        Code = code, ContentId = content.Id, QrToken = Hashing.NewQrToken(), CreatedBy = userId
                    };
                    db.Points.Add(point);
                    added++;
                }
                else
                {
                    await pipeline.SaveSourceAsync(point.Content, text, userId, ct);
                    updated++;
                }
            }
            catch (ArgumentException ex)
            {
                errors.Add($"Dòng {line} ({code}): {ex.Message}");
                continue;
            }

            point.Name = Cut(name, 150);
            point.CategoryId = category.Id;
            point.Location = Point.MakeLocation(lat, lng);
            point.RadiusM = radius;
            point.Priority = priority;
            point.FloorInfo = NullIfEmpty(Cut(row.Get("tang_phong"), 255));
            point.OpeningHours = NullIfEmpty(Cut(row.Get("gio_mo_cua"), 100));
            var image = row.Get("anh");
            if (image != "") point.ImageUrl = Cut(image, 255);
            point.UpdatedAt = DateTime.UtcNow;
            await db.SaveChangesAsync(ct);
        }
        return new ImportResult(added, updated, errors);
    }

    // Cột: thuat_ngu, ngon_ngu, cach_viet_chuan, ghi_chu
    public async Task<ImportResult> ImportGlossaryAsync(string csv, CancellationToken ct = default)
    {
        var errors = new List<string>();
        int added = 0, updated = 0, line = 1;
        var languages = await db.Languages.Select(l => l.Code).ToListAsync(ct);
        var changedTerms = new HashSet<string>();

        foreach (var row in Csv.Read(csv))
        {
            line++;
            var source = Cut(row.Get("thuat_ngu"), 150);
            var lang = row.Get("ngon_ngu").ToLowerInvariant();
            var target = Cut(row.Get("cach_viet_chuan"), 150);
            if (source == "" || target == "")
            {
                errors.Add($"Dòng {line}: thiếu thuật ngữ hoặc cách viết chuẩn.");
                continue;
            }
            if (!languages.Contains(lang))
            {
                errors.Add($"Dòng {line}: ngôn ngữ \"{lang}\" chưa có trong hệ thống.");
                continue;
            }
            var term = await db.GlossaryTerms.FirstOrDefaultAsync(g => g.SourceTerm == source && g.LanguageCode == lang, ct);
            if (term == null)
            {
                db.GlossaryTerms.Add(term = new GlossaryTerm { SourceTerm = source, LanguageCode = lang });
                added++;
            }
            else if (term.TargetTerm != target) updated++;
            else continue;
            term.TargetTerm = target;
            term.Note = NullIfEmpty(Cut(row.Get("ghi_chu"), 255));
            changedTerms.Add(source);
        }
        await db.SaveChangesAsync(ct);
        foreach (var t in changedTerms) await pipeline.EnqueueContainingAsync(t, ct);
        return new ImportResult(added, updated, errors);
    }

    private static bool TryNumber(string s, out double value) =>
        double.TryParse(s.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value);

    private static string Cut(string s, int max) => s.Length <= max ? s : s[..max];
    private static string? NullIfEmpty(string s) => s == "" ? null : s;
}
