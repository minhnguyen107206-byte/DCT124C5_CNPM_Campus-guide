using CampusGuide.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace CampusGuide.Web.Data;

/// <summary>
/// CSDL 14 bảng theo chương thiết kế CSDL của báo cáo. Tên bảng/cột dạng snake_case
/// (UseSnakeCaseNamingConvention trong Program.cs), enum lưu chữ in hoa.
/// </summary>
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Language> Languages => Set<Language>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Content> Contents => Set<Content>();
    public DbSet<Point> Points => Set<Point>();
    public DbSet<Translation> Translations => Set<Translation>();
    public DbSet<AudioFile> AudioFiles => Set<AudioFile>();
    public DbSet<GlossaryTerm> GlossaryTerms => Set<GlossaryTerm>();
    public DbSet<Tour> Tours => Set<Tour>();
    public DbSet<TourStop> TourStops => Set<TourStop>();
    public DbSet<Announcement> Announcements => Set<Announcement>();
    public DbSet<OfflinePackage> OfflinePackages => Set<OfflinePackage>();
    public DbSet<VisitorDevice> VisitorDevices => Set<VisitorDevice>();
    public DbSet<PlayLog> PlayLogs => Set<PlayLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.HasPostgresExtension("postgis");
        b.HasPostgresExtension("unaccent"); // tìm "thu vien" ra "Thư viện"

        b.Entity<User>(e =>
        {
            e.ToTable("users");
            e.Property(x => x.FullName).HasMaxLength(100).IsRequired();
            e.Property(x => x.Email).HasMaxLength(120).IsRequired();
            e.HasIndex(x => x.Email).IsUnique();
            e.Property(x => x.PasswordHash).HasMaxLength(100).IsRequired();
            Upper(e.Property(x => x.Role));
            Upper(e.Property(x => x.Status));
        });

        b.Entity<Language>(e =>
        {
            e.ToTable("languages");
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(50).IsRequired();
            e.Property(x => x.NativeName).HasMaxLength(50).IsRequired();
            e.Property(x => x.TtsVoice).HasMaxLength(60).IsRequired();
            e.Property(x => x.TtsSpeed).HasPrecision(3, 2);
            // Chỉ một ngôn ngữ dự phòng: UNIQUE (is_fallback) WHERE is_fallback
            e.HasIndex(x => x.IsFallback).IsUnique().HasFilter("is_fallback");
        });

        b.Entity<Category>(e =>
        {
            e.ToTable("categories");
            e.Property(x => x.Name).HasMaxLength(60).IsRequired();
            e.Property(x => x.Icon).HasMaxLength(40);
        });

        b.Entity<Content>(e =>
        {
            e.ToTable("contents");
            e.Property(x => x.SourceText).IsRequired();
            e.Property(x => x.ContentHash).HasMaxLength(64).IsFixedLength().IsRequired();
            e.HasOne(x => x.UpdatedByUser).WithMany().HasForeignKey(x => x.UpdatedBy).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<Point>(e =>
        {
            e.ToTable("points", t => t.HasCheckConstraint("ck_points_radius", "radius_m BETWEEN 10 AND 200"));
            e.Property(x => x.Code).HasMaxLength(20).IsRequired();
            e.HasIndex(x => x.Code).IsUnique();
            e.Property(x => x.Name).HasMaxLength(150).IsRequired();
            e.Property(x => x.Location).HasColumnType("geography(Point,4326)").IsRequired();
            e.HasIndex(x => x.Location).HasMethod("gist");
            e.Property(x => x.FloorInfo).HasMaxLength(255);
            e.Property(x => x.OpeningHours).HasMaxLength(100);
            e.Property(x => x.ImageUrl).HasMaxLength(255);
            e.Property(x => x.QrToken).HasMaxLength(32).IsRequired();
            e.HasIndex(x => x.QrToken).IsUnique();
            Upper(e.Property(x => x.Status));
            e.Ignore(x => x.Latitude);
            e.Ignore(x => x.Longitude);
            e.HasOne(x => x.Category).WithMany().HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Content).WithOne().HasForeignKey<Point>(x => x.ContentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.CreatedByUser).WithMany().HasForeignKey(x => x.CreatedBy).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<Translation>(e =>
        {
            e.ToTable("translations");
            e.HasIndex(x => new { x.ContentId, x.LanguageCode }).IsUnique();
            e.HasIndex(x => new { x.Status, x.LanguageCode });
            e.Property(x => x.LanguageCode).HasMaxLength(10);
            e.Property(x => x.SourceHash).HasMaxLength(64).IsFixedLength();
            e.Property(x => x.RejectReason).HasMaxLength(255);
            Upper(e.Property(x => x.Method));
            Upper(e.Property(x => x.Status));
            e.HasOne(x => x.Content).WithMany(c => c.Translations).HasForeignKey(x => x.ContentId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Language).WithMany().HasForeignKey(x => x.LanguageCode).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Audio).WithMany().HasForeignKey(x => x.AudioId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.ReviewedByUser).WithMany().HasForeignKey(x => x.ReviewedBy).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<AudioFile>(e =>
        {
            e.ToTable("audio_files");
            e.Property(x => x.TextHash).HasMaxLength(64).IsFixedLength();
            e.HasIndex(x => x.TextHash).IsUnique();
            e.Property(x => x.Voice).HasMaxLength(60);
            e.Property(x => x.Speed).HasPrecision(3, 2);
            e.Property(x => x.FileUrl).HasMaxLength(255);
        });

        b.Entity<GlossaryTerm>(e =>
        {
            e.ToTable("glossary_terms");
            e.Property(x => x.SourceTerm).HasMaxLength(150).IsRequired();
            e.Property(x => x.LanguageCode).HasMaxLength(10);
            e.Property(x => x.TargetTerm).HasMaxLength(150).IsRequired();
            e.Property(x => x.Note).HasMaxLength(255);
            e.HasIndex(x => new { x.SourceTerm, x.LanguageCode }).IsUnique();
            e.HasOne(x => x.Language).WithMany().HasForeignKey(x => x.LanguageCode).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Tour>(e =>
        {
            e.ToTable("tours");
            e.Property(x => x.Name).HasMaxLength(150).IsRequired();
            Upper(e.Property(x => x.Status));
            e.HasOne(x => x.Content).WithMany().HasForeignKey(x => x.ContentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.CreatedBy).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<TourStop>(e =>
        {
            e.ToTable("tour_stops");
            e.HasKey(x => new { x.TourId, x.PointId });
            e.HasIndex(x => new { x.TourId, x.StopOrder }).IsUnique();
            e.HasOne(x => x.Tour).WithMany(t => t.Stops).HasForeignKey(x => x.TourId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Point).WithMany().HasForeignKey(x => x.PointId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Announcement>(e =>
        {
            e.ToTable("announcements", t => t.HasCheckConstraint("ck_announcements_time", "start_at < end_at"));
            e.Property(x => x.Title).HasMaxLength(150).IsRequired();
            Upper(e.Property(x => x.Status));
            e.HasOne(x => x.Content).WithMany().HasForeignKey(x => x.ContentId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Point).WithMany().HasForeignKey(x => x.PointId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne<User>().WithMany().HasForeignKey(x => x.CreatedBy).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<OfflinePackage>(e =>
        {
            e.ToTable("offline_packages");
            e.Property(x => x.LanguageCode).HasMaxLength(10);
            e.Property(x => x.FileUrl).HasMaxLength(255);
            e.Property(x => x.Checksum).HasMaxLength(64).IsFixedLength();
            e.HasIndex(x => new { x.TourId, x.LanguageCode, x.TourVersion }).IsUnique();
            e.HasOne(x => x.Tour).WithMany().HasForeignKey(x => x.TourId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne<Language>().WithMany().HasForeignKey(x => x.LanguageCode).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<VisitorDevice>(e =>
        {
            e.ToTable("visitor_devices");
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.LanguageCode).HasMaxLength(10);
            Upper(e.Property(x => x.Platform));
            e.Property(x => x.AppVersion).HasMaxLength(20);
            e.HasOne<Language>().WithMany().HasForeignKey(x => x.LanguageCode).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<PlayLog>(e =>
        {
            e.ToTable("play_logs");
            e.Property(x => x.LanguageCode).HasMaxLength(10);
            Upper(e.Property(x => x.TriggerType));
            e.HasIndex(x => new { x.DeviceId, x.PointId, x.PlayedAt }).IsDescending(false, false, true);
            e.HasIndex(x => x.PlayedAt);
            e.HasOne(x => x.Device).WithMany().HasForeignKey(x => x.DeviceId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Point).WithMany().HasForeignKey(x => x.PointId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne<Language>().WithMany().HasForeignKey(x => x.LanguageCode).OnDelete(DeleteBehavior.Restrict);
        });
    }

    /// <summary>Lưu enum thành chuỗi in hoa varchar(10), ví dụ TranslationStatus.Pending → 'PENDING'.</summary>
    private static void Upper<TEnum>(PropertyBuilder<TEnum> p) where TEnum : struct, Enum
    {
        p.HasConversion(new ValueConverter<TEnum, string>(
            v => v.ToString().ToUpperInvariant(),
            v => Enum.Parse<TEnum>(v, true)));
        p.HasMaxLength(10);
    }
}
