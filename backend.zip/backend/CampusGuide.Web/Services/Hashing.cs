using System.Security.Cryptography;
using System.Text;

namespace CampusGuide.Web.Services;

public static class Hashing
{
    /// <summary>SHA-256 dạng hex thường (64 ký tự), dùng cho content_hash, source_hash, text_hash, checksum.</summary>
    public static string Sha256(string text) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text))).ToLowerInvariant();

    public static string Sha256(byte[] data) =>
        Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

    /// <summary>Chuẩn hoá văn bản trước khi băm: bỏ khoảng trắng thừa ở đầu/cuối, thống nhất xuống dòng.</summary>
    public static string NormalizeText(string text) =>
        text.Replace("\r\n", "\n").Trim();

    /// <summary>Token ngẫu nhiên in trong mã QR (chữ thường + số, không có ký tự dễ nhầm).</summary>
    public static string NewQrToken(int length = 32)
    {
        const string alphabet = "abcdefghjkmnpqrstuvwxyz23456789";
        return RandomNumberGenerator.GetString(alphabet, length);
    }
}
