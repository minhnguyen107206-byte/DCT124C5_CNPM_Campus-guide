using System.Threading.Channels;
using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Services;

/// <summary>Một yêu cầu dịch nội dung. Force = dịch lại cả khi nội dung gốc không đổi (ví dụ vừa sửa thuật ngữ).</summary>
public record TranslationJob(long ContentId, bool Force = false);

/// <summary>Hàng đợi dịch bất đồng bộ: trang Admin lưu xong là trả về ngay, việc dịch chạy nền.</summary>
public class TranslationQueue
{
    private readonly Channel<TranslationJob> _channel = Channel.CreateUnbounded<TranslationJob>();
    private int _count;

    public int Count => _count;

    public void Enqueue(TranslationJob job)
    {
        Interlocked.Increment(ref _count);
        _channel.Writer.TryWrite(job);
    }

    public async IAsyncEnumerable<TranslationJob> ReadAllAsync([System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        await foreach (var job in _channel.Reader.ReadAllAsync(ct))
        {
            Interlocked.Decrement(ref _count);
            yield return job;
        }
    }
}

/// <summary>Tiến trình nền lấy việc trong hàng đợi và gọi TranslationPipeline.</summary>
public class TranslationWorker(TranslationQueue queue, IServiceScopeFactory scopes, ILogger<TranslationWorker> log) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var job in queue.ReadAllAsync(stoppingToken))
        {
            try
            {
                using var scope = scopes.CreateScope();
                var pipeline = scope.ServiceProvider.GetRequiredService<TranslationPipeline>();
                await pipeline.ProcessAsync(job.ContentId, job.Force, stoppingToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                log.LogError(ex, "Dịch nội dung {ContentId} thất bại", job.ContentId);
            }
        }
    }
}

/// <summary>
/// Luồng nội dung đa ngôn ngữ (UC nhập nội dung, dịch tự động, duyệt bản dịch, sinh audio):
/// lưu nội dung gốc → dịch sang các ngôn ngữ đang bật (áp thuật ngữ) → chờ duyệt → duyệt thì sinh audio (có cache).
/// </summary>
public class TranslationPipeline(
    AppDbContext db,
    ITranslationService translator,
    ITtsService tts,
    IFileStorage storage,
    TranslationQueue queue,
    ILogger<TranslationPipeline> log)
{
    /// <summary>
    /// Tạo mới (content == null) hoặc cập nhật nội dung gốc. Nếu văn bản đổi thì tăng version,
    /// đánh dấu các bản dịch cũ là OUTDATED và đưa vào hàng đợi dịch lại.
    /// </summary>
    public async Task<Content> SaveSourceAsync(Content? content, string text, long? userId, CancellationToken ct = default)
    {
        text = Hashing.NormalizeText(text);
        if (text.Length > Content.MaxLength)
            throw new ArgumentException($"Nội dung tối đa {Content.MaxLength} ký tự.");
        var hash = Hashing.Sha256(text);

        if (content == null)
        {
            content = new Content { SourceText = text, ContentHash = hash, UpdatedBy = userId };
            db.Contents.Add(content);
        }
        else if (content.ContentHash == hash)
        {
            return content;
        }
        else
        {
            content.SourceText = text;
            content.ContentHash = hash;
            content.Version++;
            content.UpdatedBy = userId;
            content.UpdatedAt = DateTime.UtcNow;
            var olds = await db.Translations
                .Where(t => t.ContentId == content.Id && t.LanguageCode != Language.SourceCode)
                .ToListAsync(ct);
            foreach (var t in olds) t.Status = TranslationStatus.Outdated;
        }

        await db.SaveChangesAsync(ct);
        queue.Enqueue(new TranslationJob(content.Id));
        return content;
    }

    /// <summary>Dịch một nội dung sang mọi ngôn ngữ đang bật. Được gọi từ TranslationWorker.</summary>
    public async Task ProcessAsync(long contentId, bool force, CancellationToken ct = default)
    {
        var content = await db.Contents.Include(c => c.Translations).FirstOrDefaultAsync(c => c.Id == contentId, ct);
        if (content == null) return;
        var languages = await db.Languages.Where(l => l.IsActive).ToListAsync(ct);

        foreach (var lang in languages)
        {
            var tr = content.Translations.FirstOrDefault(t => t.LanguageCode == lang.Code);
            if (tr == null)
            {
                tr = new Translation { ContentId = content.Id, LanguageCode = lang.Code };
                content.Translations.Add(tr);
            }

            if (lang.Code == Language.SourceCode)
            {
                // Bản tiếng Việt chính là nội dung gốc: duyệt sẵn, chỉ cần sinh audio.
                if (tr.SourceHash != content.ContentHash || tr.TranslatedText != content.SourceText)
                {
                    tr.TranslatedText = content.SourceText;
                    tr.SourceHash = content.ContentHash;
                    tr.Method = TranslationMethod.Human;
                    tr.Status = TranslationStatus.Approved;
                    tr.ReviewedBy = content.UpdatedBy;
                    tr.ReviewedAt = DateTime.UtcNow;
                    tr.AudioId = null;
                }
                await TryEnsureAudioAsync(tr, lang, force: false, ct);
                continue;
            }

            var upToDate = tr.SourceHash == content.ContentHash
                           && tr.Status is not (TranslationStatus.Failed or TranslationStatus.Outdated);
            if (upToDate && (!force || tr.Method == TranslationMethod.Human)) continue;

            await MachineTranslateAsync(content, tr, ct);
        }

        await db.SaveChangesAsync(ct);
    }

    /// <summary>Dịch máy một bản dịch (gọi khi nhấn "Dịch lại" hoặc từ ProcessAsync). Không tự SaveChanges.</summary>
    private async Task MachineTranslateAsync(Content content, Translation tr, CancellationToken ct)
    {
        var glossary = await db.GlossaryTerms
            .Where(g => g.LanguageCode == tr.LanguageCode)
            .Select(g => new GlossaryPair(g.SourceTerm, g.TargetTerm))
            .ToListAsync(ct);
        try
        {
            tr.TranslatedText = await translator.TranslateAsync(content.SourceText, Language.SourceCode, tr.LanguageCode, glossary, ct);
            tr.Status = TranslationStatus.Pending;
            tr.RejectReason = null;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            log.LogWarning(ex, "Dịch nội dung {ContentId} sang {Lang} lỗi", content.Id, tr.LanguageCode);
            tr.Status = TranslationStatus.Failed;
            tr.RejectReason = Truncate(ex.Message, 255);
        }
        tr.SourceHash = content.ContentHash;
        tr.Method = TranslationMethod.Machine;
        tr.AudioId = null;
        tr.ReviewedBy = null;
        tr.ReviewedAt = null;
    }

    public async Task RetranslateAsync(long translationId, CancellationToken ct = default)
    {
        var tr = await LoadAsync(translationId, ct);
        if (tr.LanguageCode == Language.SourceCode) return;
        await MachineTranslateAsync(tr.Content!, tr, ct);
        await db.SaveChangesAsync(ct);
    }

    public async Task ApproveAsync(long translationId, long userId, CancellationToken ct = default)
    {
        var tr = await LoadAsync(translationId, ct);
        if (string.IsNullOrWhiteSpace(tr.TranslatedText))
            throw new InvalidOperationException("Bản dịch đang trống, không thể duyệt.");
        tr.Status = TranslationStatus.Approved;
        tr.ReviewedBy = userId;
        tr.ReviewedAt = DateTime.UtcNow;
        tr.RejectReason = null;
        await db.SaveChangesAsync(ct);
        await TryEnsureAudioAsync(tr, tr.Language!, force: false, ct);
        await db.SaveChangesAsync(ct);
    }

    public async Task RejectAsync(long translationId, long userId, string reason, CancellationToken ct = default)
    {
        var tr = await LoadAsync(translationId, ct);
        tr.Status = TranslationStatus.Rejected;
        tr.ReviewedBy = userId;
        tr.ReviewedAt = DateTime.UtcNow;
        tr.RejectReason = Truncate(reason, 255);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Biên tập viên sửa tay bản dịch (method = HUMAN). approve = true thì duyệt luôn và sinh audio.</summary>
    public async Task SaveHumanEditAsync(long translationId, string text, long userId, bool approve, CancellationToken ct = default)
    {
        var tr = await LoadAsync(translationId, ct);
        text = Hashing.NormalizeText(text);
        if (tr.TranslatedText != text)
        {
            tr.TranslatedText = text;
            tr.Method = TranslationMethod.Human;
            tr.AudioId = null;
        }
        tr.SourceHash = tr.Content!.ContentHash;
        tr.Status = TranslationStatus.Pending;
        tr.RejectReason = null;
        await db.SaveChangesAsync(ct);
        if (approve) await ApproveAsync(tr.Id, userId, ct);
    }

    public async Task RegenerateAudioAsync(long translationId, CancellationToken ct = default)
    {
        var tr = await LoadAsync(translationId, ct);
        if (tr.Status != TranslationStatus.Approved)
            throw new InvalidOperationException("Chỉ sinh audio cho bản dịch đã duyệt.");
        await EnsureAudioAsync(tr, tr.Language!, force: true, ct);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Khi bật ngôn ngữ mới: dịch toàn bộ nội dung sang ngôn ngữ đó.</summary>
    public async Task EnqueueAllAsync(CancellationToken ct = default)
    {
        foreach (var id in await db.Contents.Select(c => c.Id).ToListAsync(ct))
            queue.Enqueue(new TranslationJob(id));
    }

    /// <summary>Khi thêm/sửa thuật ngữ: dịch lại (bằng máy) các nội dung có chứa thuật ngữ đó.</summary>
    public async Task<int> EnqueueContainingAsync(string sourceTerm, CancellationToken ct = default)
    {
        var pattern = "%" + sourceTerm.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_") + "%";
        var ids = await db.Contents.Where(c => EF.Functions.ILike(c.SourceText, pattern)).Select(c => c.Id).ToListAsync(ct);
        foreach (var id in ids) queue.Enqueue(new TranslationJob(id, Force: true));
        return ids.Count;
    }

    private async Task TryEnsureAudioAsync(Translation tr, Language lang, bool force, CancellationToken ct)
    {
        try
        {
            await EnsureAudioAsync(tr, lang, force, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            // Lỗi sinh audio không làm mất bản dịch; biên tập viên bấm "Sinh lại audio" sau.
            log.LogWarning(ex, "Sinh audio cho bản dịch {Id} ({Lang}) lỗi", tr.Id, tr.LanguageCode);
        }
    }

    /// <summary>Sinh audio cho bản dịch đã duyệt. Cache theo SHA-256(văn bản + giọng + tốc độ) nên văn bản trùng không tốn tiền gọi lại.</summary>
    private async Task EnsureAudioAsync(Translation tr, Language lang, bool force, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(tr.TranslatedText)) return;
        var hash = Hashing.Sha256($"{tr.TranslatedText}|{lang.TtsVoice}|{lang.TtsSpeed:0.00}");
        var audio = await db.AudioFiles.FirstOrDefaultAsync(a => a.TextHash == hash, ct);
        if (audio != null && !force)
        {
            tr.AudioId = audio.Id;
            return;
        }

        var result = await tts.SynthesizeAsync(tr.TranslatedText, lang.TtsVoice, lang.TtsSpeed, ct);
        if (result == null)
        {
            tr.AudioId = null; 
            return;
        }

        var url = await storage.SaveAsync($"audio/{lang.Code}/{hash}.mp3", result.Mp3, "audio/mpeg", ct);
        if (audio == null)
        {
            audio = new AudioFile { TextHash = hash };
            db.AudioFiles.Add(audio);
        }
        audio.Voice = lang.TtsVoice;
        audio.Speed = lang.TtsSpeed;
        audio.FileUrl = url;
        audio.DurationMs = result.DurationMs;
        audio.SizeBytes = result.Mp3.Length;
        audio.CreatedAt = DateTime.UtcNow;
        tr.Audio = audio;
    }

    private async Task<Translation> LoadAsync(long id, CancellationToken ct) =>
        await db.Translations.Include(t => t.Content).Include(t => t.Language).FirstOrDefaultAsync(t => t.Id == id, ct)
        ?? throw new KeyNotFoundException($"Không tìm thấy bản dịch {id}.");

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max];
}
