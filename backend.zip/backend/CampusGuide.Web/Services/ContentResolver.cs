using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Services;

/// <summary>Nội dung trả cho app: văn bản, audio và ngôn ngữ thực tế đã dùng.</summary>
public record ResolvedContent(string LanguageCode, string Text, string? AudioUrl, int? DurationMs, bool IsFallback);

/// <summary>
/// Chọn bản thuyết minh cho khách theo thứ tự: ngôn ngữ khách chọn (bản đã duyệt)
/// → ngôn ngữ dự phòng (is_fallback) → nội dung gốc tiếng Việt.
/// </summary>
public class ContentResolver(AppDbContext db)
{
    public async Task<string> FallbackCodeAsync(CancellationToken ct = default) =>
        await db.Languages.Where(l => l.IsFallback && l.IsActive).Select(l => l.Code).FirstOrDefaultAsync(ct)
        ?? Language.SourceCode;

    public async Task<ResolvedContent?> ResolveAsync(long contentId, string? lang, CancellationToken ct = default)
    {
        var map = await ResolveManyAsync(new[] { contentId }, lang, ct);
        return map.GetValueOrDefault(contentId);
    }

    /// <summary>Phiên bản cho nhiều nội dung cùng lúc (danh sách điểm, tour) để tránh truy vấn lặp.</summary>
    public async Task<Dictionary<long, ResolvedContent>> ResolveManyAsync(IEnumerable<long> contentIds, string? lang, CancellationToken ct = default)
    {
        var ids = contentIds.Distinct().ToList();
        lang = string.IsNullOrWhiteSpace(lang) ? Language.SourceCode : lang.Trim().ToLowerInvariant();
        var order = new List<string> { lang, await FallbackCodeAsync(ct), Language.SourceCode }.Distinct().ToList();

        var translations = await db.Translations
            .Where(t => ids.Contains(t.ContentId) && order.Contains(t.LanguageCode)
                        && t.Status == TranslationStatus.Approved && t.TranslatedText != null && t.TranslatedText != "")
            .Include(t => t.Audio)
            .AsNoTracking()
            .ToListAsync(ct);
        var sources = await db.Contents.Where(c => ids.Contains(c.Id))
            .Select(c => new { c.Id, c.SourceText })
            .ToDictionaryAsync(c => c.Id, c => c.SourceText, ct);

        var result = new Dictionary<long, ResolvedContent>();
        foreach (var id in ids)
        {
            var best = order
                .Select(code => translations.FirstOrDefault(t => t.ContentId == id && t.LanguageCode == code))
                .FirstOrDefault(t => t != null);
            if (best != null)
                result[id] = new ResolvedContent(best.LanguageCode, best.TranslatedText!, best.Audio?.FileUrl,
                    best.Audio?.DurationMs, best.LanguageCode != lang);
            else if (sources.TryGetValue(id, out var src))
                result[id] = new ResolvedContent(Language.SourceCode, src, null, null, lang != Language.SourceCode);
        }
        return result;
    }
}
