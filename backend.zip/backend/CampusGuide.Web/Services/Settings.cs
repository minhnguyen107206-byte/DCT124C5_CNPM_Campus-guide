namespace CampusGuide.Web.Services;

/// <summary>
/// Mục "GoogleCloud" trong appsettings.Development.json. Để trống ApiKey thì hệ thống dùng bản dịch
/// giả lập và không sinh MP3 (app đọc bằng giọng của điện thoại), đủ để chạy thử khi chưa có tài khoản Google Cloud.
/// </summary>
public class GoogleCloudOptions
{
    public string? ApiKey { get; set; }
    public bool Enabled => !string.IsNullOrWhiteSpace(ApiKey);
}

/// <summary>Mục "Storage": để trống Url thì lưu file vào wwwroot/media trên máy chạy backend.</summary>
public class StorageOptions
{
    /// <summary>Ví dụ https://xxxx.supabase.co</summary>
    public string? Url { get; set; }
    /// <summary>service_role key của Supabase (chỉ để ở máy chủ, không đưa vào app).</summary>
    public string? Key { get; set; }
    public string Bucket { get; set; } = "campus-guide";
}

/// <summary>Mục "App": cấu hình chung.</summary>
public class AppOptions
{
    /// <summary>Địa chỉ in trong mã QR, ví dụ https://campusguide.example.com. Để trống thì lấy theo địa chỉ đang truy cập.</summary>
    public string? PublicBaseUrl { get; set; }

    /// <summary>Tâm khuôn viên (mặc định cơ sở chính 273 An Dương Vương) và bán kính cho phép đặt điểm.</summary>
    public double CampusLatitude { get; set; } = 10.7598;
    public double CampusLongitude { get; set; } = 106.6822;
    public int CampusRadiusM { get; set; } = 1000;

    /// <summary>Không tự phát lại một điểm cho cùng thiết bị trong khoảng này (chống phát lặp).</summary>
    public int ReplayCooldownMinutes { get; set; } = 30;

    public bool IsInsideCampus(double lat, double lng) =>
        Geo.DistanceM(Models.Point.MakeLocation(CampusLatitude, CampusLongitude), Models.Point.MakeLocation(lat, lng)) <= CampusRadiusM;
        public class TranslationOptions
 {
    /// <summary>"MyMemory" (miễn phí, cần Internet) hoặc "Mock" (giả lập, không cần mạng).</summary>
    public string Provider { get; set; } = "MyMemory";
    /// <summary>Email của bạn: MyMemory tăng hạn mức từ ~5.000 lên ~50.000 ký tự/ngày.</summary>
    public string? Email { get; set; }
    public string MyMemoryUrl { get; set; } = "https://api.mymemory.translated.net";
 }
}
