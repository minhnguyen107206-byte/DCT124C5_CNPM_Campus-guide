using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;

namespace CampusGuide.Web.Services;

/// <summary>Cặp thuật ngữ áp dụng khi dịch: tiếng Việt → cách viết chuẩn ở ngôn ngữ đích.</summary>
public record GlossaryPair(string Source, string Target);

public class TranslationOptions
{
    public string MyMemoryUrl { get; set; } = "https://api.mymemory.translated.net";
    public string? Email { get; set; }
}

public interface ITranslationService
{
    /// <summary>Tên hiển thị của bộ dịch đang dùng (hiện ở trang Admin).</summary>
    string Name { get; }

    Task<string> TranslateAsync(string text, string sourceLang, string targetLang,
        IReadOnlyList<GlossaryPair> glossary, CancellationToken ct = default);
}

/// <summary>
/// Áp bảng thuật ngữ: thay thuật ngữ tiếng Việt bằng cách viết chuẩn và bọc trong
/// &lt;span translate="no"&gt; để Google Translate giữ nguyên khi dịch dạng HTML.
/// </summary>
public static class GlossaryMarkup
{
    private static readonly Regex Span = new("<span translate=\"no\">(.*?)</span>", RegexOptions.Singleline);
    private static readonly Regex Br = new(@"<br\s*/?>", RegexOptions.IgnoreCase);

    public static string ToHtml(string text, IReadOnlyList<GlossaryPair> glossary)
    {
        var html = WebUtility.HtmlEncode(text);
        foreach (var g in glossary.OrderByDescending(g => g.Source.Length))
        {
            var src = WebUtility.HtmlEncode(g.Source);
            var pattern = $@"(?<![\p{{L}}\p{{N}}]){Regex.Escape(src)}(?![\p{{L}}\p{{N}}])";
            html = Regex.Replace(html, pattern,
                _ => $"<span translate=\"no\">{WebUtility.HtmlEncode(g.Target)}</span>",
                RegexOptions.IgnoreCase);
        }
        return html.Replace("\n", "<br>");
    }

    public static string FromHtml(string html)
    {
        var text = Br.Replace(html, "\n");
        text = Span.Replace(text, m => m.Groups[1].Value);
        return WebUtility.HtmlDecode(text).Trim();
    }

    /// <summary>Chỉ thay thuật ngữ, không dịch (dùng cho bộ dịch giả lập).</summary>
    public static string ApplyPlain(string text, IReadOnlyList<GlossaryPair> glossary) =>
        FromHtml(ToHtml(text, glossary));
}

/// <summary>Bộ dịch giả lập khi chưa có API key: giữ câu tiếng Việt, gắn nhãn [EN]... và áp thuật ngữ.</summary>
public class MockTranslationService : ITranslationService
{
    public string Name => "Giả lập (chưa cấu hình GoogleCloud:ApiKey)";

    public Task<string> TranslateAsync(string text, string sourceLang, string targetLang,
        IReadOnlyList<GlossaryPair> glossary, CancellationToken ct = default) =>
        Task.FromResult($"[{targetLang.ToUpperInvariant()}] {GlossaryMarkup.ApplyPlain(text, glossary)}");
}

/// <summary>Google Cloud Translation API v2 (REST, xác thực bằng API key).</summary>
public class GoogleTranslationService(HttpClient http, IOptions<GoogleCloudOptions> options) : ITranslationService
{
    private const string Endpoint = "https://translation.googleapis.com/language/translate/v2";

    public string Name => "Google Cloud Translation";

    public async Task<string> TranslateAsync(string text, string sourceLang, string targetLang,
        IReadOnlyList<GlossaryPair> glossary, CancellationToken ct = default)
    {
        var body = new
        {
            q = new[] { GlossaryMarkup.ToHtml(text, glossary) },
            source = sourceLang,
            target = targetLang,
            format = "html"
        };
        using var res = await http.PostAsJsonAsync($"{Endpoint}?key={Uri.EscapeDataString(options.Value.ApiKey!)}", body, ct);
        if (!res.IsSuccessStatusCode)
            throw new InvalidOperationException($"Google Translation lỗi {(int)res.StatusCode}: {await res.Content.ReadAsStringAsync(ct)}");
        var json = await res.Content.ReadFromJsonAsync<Response>(cancellationToken: ct);
        var translated = json?.Data?.Translations?.FirstOrDefault()?.TranslatedText
                         ?? throw new InvalidOperationException("Google Translation không trả về bản dịch.");
        return GlossaryMarkup.FromHtml(translated);
    }

    private record Response([property: JsonPropertyName("data")] Data? Data);
    private record Data([property: JsonPropertyName("translations")] List<Item>? Translations);
    private record Item([property: JsonPropertyName("translatedText")] string TranslatedText);
}

 /// <summary>Bộ dịch miễn phí MyMemory, không cần thẻ hay API key. Mỗi yêu cầu tối đa 500 byte nên văn bản được cắt nhỏ.</summary>
public class MyMemoryTranslationService(HttpClient http, IOptions<TranslationOptions> options) : ITranslationService
{
    private const int MaxBytes = 450;

    public string Name => "MyMemory";

    public async Task<string> TranslateAsync(string text, string sourceLang, string targetLang,
        IReadOnlyList<GlossaryPair> glossary, CancellationToken ct = default)
    {
        var o = options.Value;
        var prepared = GlossaryMarkup.ApplyPlain(text, glossary);
        var result = new System.Text.StringBuilder();
        foreach (var paragraph in prepared.Split('\n'))
        {
            if (result.Length > 0) result.Append('\n');
            if (string.IsNullOrWhiteSpace(paragraph)) continue;
            var parts = new List<string>();
            foreach (var chunk in GoogleTtsService.SplitByBytes(paragraph, MaxBytes))
            {
                var url = $"{o.MyMemoryUrl.TrimEnd('/')}/get?q={Uri.EscapeDataString(chunk.Trim())}" +
                          $"&langpair={Code(sourceLang)}|{Code(targetLang)}" +
                          (string.IsNullOrWhiteSpace(o.Email) ? "" : $"&de={Uri.EscapeDataString(o.Email)}");
                var json = await http.GetFromJsonAsync<Response>(url, ct)
                           ?? throw new InvalidOperationException("MyMemory không trả kết quả.");
                if (json.ResponseStatus is not (200 or null) || json.ResponseData?.TranslatedText == null)
                    throw new InvalidOperationException($"MyMemory lỗi {json.ResponseStatus}: {json.ResponseDetails}");
                if (json.QuotaFinished == true)
                    throw new InvalidOperationException("MyMemory đã hết hạn mức hôm nay. Điền Translation:Email để tăng hạn mức hoặc thử lại ngày mai.");
                parts.Add(WebUtility.HtmlDecode(json.ResponseData.TranslatedText).Trim());
            }
            result.Append(string.Join(' ', parts));
        }
        return result.ToString().Trim();
    }

    // MyMemory cần mã vùng cho tiếng Trung.
    private static string Code(string lang) => lang == "zh" ? "zh-CN" : lang;

    private record Response(
        [property: JsonPropertyName("responseData")] Data? ResponseData,
        [property: JsonPropertyName("responseStatus"), JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)] int? ResponseStatus,
        [property: JsonPropertyName("responseDetails")] string? ResponseDetails,
        [property: JsonPropertyName("quotaFinished")] bool? QuotaFinished);
    private record Data([property: JsonPropertyName("translatedText")] string? TranslatedText);
}
