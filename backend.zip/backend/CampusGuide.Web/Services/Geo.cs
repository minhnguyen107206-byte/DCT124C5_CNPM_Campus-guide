namespace CampusGuide.Web.Services;

public static class Geo
{
    /// <summary>Khoảng cách mặt đất (m) giữa hai điểm WGS84, công thức haversine.</summary>
    public static double DistanceM(NetTopologySuite.Geometries.Point a, NetTopologySuite.Geometries.Point b)
    {
        const double r = 6371000;
        double ToRad(double d) => d * Math.PI / 180;
        var dLat = ToRad(b.Y - a.Y);
        var dLng = ToRad(b.X - a.X);
        var h = Math.Sin(dLat / 2) * Math.Sin(dLat / 2)
                + Math.Cos(ToRad(a.Y)) * Math.Cos(ToRad(b.Y)) * Math.Sin(dLng / 2) * Math.Sin(dLng / 2);
        return 2 * r * Math.Asin(Math.Sqrt(h));
    }
}
