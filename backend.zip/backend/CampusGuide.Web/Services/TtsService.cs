using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Options;

namespace CampusGuide.Web.Services;

/// <summary>Kết quả sinh giọng đọc: dữ liệu MP3 và thời lượng ước tính.</summary>
public record TtsResult(byte[] Mp3, int DurationMs);

public interface ITtsService
{
    string Name { get; }

    /// <summary>Trả về null khi không sinh được file (chế độ giả lập): app và trang Admin sẽ đọc bằng giọng của thiết bị.</summary>
    Task<TtsResult?> SynthesizeAsync(string text, string voice, decimal speed, CancellationToken ct = default);
}

public class MockTtsService : ITtsService
{
    public string Name => "Giọng của thiết bị";

    public Task<TtsResult?> SynthesizeAsync(string text, string voice, decimal speed, CancellationToken ct = default) =>
        Task.FromResult<TtsResult?>(null);
}

/// <summary>Google Cloud Text-to-Speech v1 (REST, xác thực bằng API key).</summary>
public class GoogleTtsService(HttpClient http, IOptions<GoogleCloudOptions> options) : ITtsService
{
    private const string Endpoint = "https://texttospeech.googleapis.com/v1/text:synthesize";
    // Google giới hạn 5000 byte mỗi yêu cầu; tiếng Việt có dấu tốn 2–3 byte/ký tự nên cắt theo câu.
    private const int MaxBytes = 4500;
    // MP3 mặc định của Google TTS là 32 kbps → 4 byte mỗi mili giây.
    private const int BytesPerMs = 4;

    public string Name => "Google Cloud Text-to-Speech";

    public async Task<TtsResult?> SynthesizeAsync(string text, string voice, decimal speed, CancellationToken ct = default)
    {
        var languageCode = string.Join('-', voice.Split('-').Take(2)); // "vi-VN-Standard-A" → "vi-VN"
        using var mp3 = new MemoryStream();
        foreach (var chunk in SplitByBytes(text, MaxBytes))
        {
            var body = new
            {
                input = new { text = chunk },
                voice = new { languageCode, name = voice },
                audioConfig = new { audioEncoding = "MP3", speakingRate = speed }
            };
            using var res = await http.PostAsJsonAsync($"{Endpoint}?key={Uri.EscapeDataString(options.Value.ApiKey!)}", body, ct);
            if (!res.IsSuccessStatusCode)
                throw new InvalidOperationException($"Google TTS lỗi {(int)res.StatusCode}: {await res.Content.ReadAsStringAsync(ct)}");
            var json = await res.Content.ReadFromJsonAsync<Response>(cancellationToken: ct);
            var bytes = Convert.FromBase64String(json?.AudioContent ?? "");
            await mp3.WriteAsync(bytes, ct); // các đoạn MP3 nối tiếp vẫn phát được liền mạch
        }
        var data = mp3.ToArray();
        return new TtsResult(data, data.Length / BytesPerMs);
    }

    internal static IEnumerable<string> SplitByBytes(string text, int maxBytes)
    {
        if (Encoding.UTF8.GetByteCount(text) <= maxBytes)
        {
            yield return text;
            yield break;
        }
        var sb = new StringBuilder();
        foreach (var sentence in System.Text.RegularExpressions.Regex.Split(text, @"(?<=[.!?。！？\n])\s*"))
        {
            if (sb.Length > 0 && Encoding.UTF8.GetByteCount(sb + sentence) > maxBytes)
            {
                yield return sb.ToString();
                sb.Clear();
            }
            sb.Append(sentence).Append(' ');
        }
        if (sb.Length > 0) yield return sb.ToString();
    }

    private record Response([property: JsonPropertyName("audioContent")] string? AudioContent);
}
