using Microsoft.Extensions.Options;
using QRCoder;

namespace CampusGuide.Web.Services;

/// <summary>
/// Sinh mã QR cho điểm. Nội dung mã là đường dẫn {PublicBaseUrl}/q/{qr_token}:
/// app CampusGuide lấy phần token cuối đường dẫn và gọi GET /api/app/qr/{token};
/// điện thoại chưa cài app mở đường dẫn sẽ thấy trang nghe thử trên web.
/// </summary>
public class QrService(IOptions<AppOptions> options, IHttpContextAccessor http)
{
    public string BuildUrl(string qrToken)
    {
        var baseUrl = options.Value.PublicBaseUrl;
        if (string.IsNullOrWhiteSpace(baseUrl))
        {
            var req = http.HttpContext?.Request;
            baseUrl = req == null ? "http://localhost:5000" : $"{req.Scheme}://{req.Host}";
        }
        return $"{baseUrl.TrimEnd('/')}/q/{qrToken}";
    }

    /// <summary>Ảnh PNG của mã QR, mức sửa lỗi Q (chịu được ~25% hư hỏng khi in dán ngoài trời).</summary>
    public byte[] RenderPng(string qrToken, int pixelsPerModule = 10)
    {
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(BuildUrl(qrToken), QRCodeGenerator.ECCLevel.Q);
        return new PngByteQRCode(data).GetGraphic(pixelsPerModule);
    }

    /// <summary>Lấy token từ chuỗi quét được (chấp nhận cả đường dẫn đầy đủ lẫn token trần).</summary>
    public static string ExtractToken(string scanned)
    {
        var s = scanned.Trim().TrimEnd('/');
        var i = s.LastIndexOf('/');
        return i >= 0 ? s[(i + 1)..] : s;
    }
}
