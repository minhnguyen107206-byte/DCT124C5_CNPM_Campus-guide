using System.Net.Http.Headers;
using Microsoft.Extensions.Options;

namespace CampusGuide.Web.Services;

public interface IFileStorage
{
    /// <summary>Lưu file và trả về URL (tương đối "/media/..." khi lưu cục bộ, tuyệt đối khi lưu Supabase).</summary>
    Task<string> SaveAsync(string path, byte[] data, string contentType, CancellationToken ct = default);
}

/// <summary>Lưu vào wwwroot/media, phục vụ qua /media/... (mặc định khi chạy trên máy).</summary>
public class LocalFileStorage(IWebHostEnvironment env) : IFileStorage
{
    public async Task<string> SaveAsync(string path, byte[] data, string contentType, CancellationToken ct = default)
    {
        path = path.Replace('\\', '/').TrimStart('/');
        var full = Path.Combine(env.WebRootPath, "media", path.Replace('/', Path.DirectorySeparatorChar));
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllBytesAsync(full, data, ct);
        return "/media/" + path;
    }
}

/// <summary>Lưu lên Supabase Storage (bucket public) khi có cấu hình Storage:Url và Storage:Key.</summary>
public class SupabaseFileStorage(HttpClient http, IOptions<StorageOptions> options) : IFileStorage
{
    private readonly StorageOptions _o = options.Value;

    public async Task<string> SaveAsync(string path, byte[] data, string contentType, CancellationToken ct = default)
    {
        path = path.Replace('\\', '/').TrimStart('/');
        var baseUrl = _o.Url!.TrimEnd('/');
        using var req = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/storage/v1/object/{_o.Bucket}/{path}");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _o.Key);
        req.Headers.Add("x-upsert", "true");
        req.Content = new ByteArrayContent(data);
        req.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
        using var res = await http.SendAsync(req, ct);
        if (!res.IsSuccessStatusCode)
            throw new InvalidOperationException($"Supabase Storage trả lỗi {(int)res.StatusCode}: {await res.Content.ReadAsStringAsync(ct)}");
        return $"{baseUrl}/storage/v1/object/public/{_o.Bucket}/{path}";
    }
}
