using CampusGuide.Web.Data;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var config = builder.Configuration;

// ---- CSDL: PostgreSQL + PostGIS, tên bảng/cột snake_case như báo cáo ----
builder.Services.AddDbContext<AppDbContext>(o => o
    .UseNpgsql(config.GetConnectionString("Default")
               ?? throw new InvalidOperationException("Thiếu ConnectionStrings:Default trong appsettings.Development.json"),
        npgsql => npgsql.UseNetTopologySuite())
    .UseSnakeCaseNamingConvention());

// ---- Cấu hình ----
builder.Services.Configure<GoogleCloudOptions>(config.GetSection("GoogleCloud"));
builder.Services.Configure<StorageOptions>(config.GetSection("Storage"));
builder.Services.Configure<TranslationOptions>(config.GetSection("Translation"));
builder.Services.Configure<AppOptions>(config.GetSection("App"));
var google = config.GetSection("GoogleCloud").Get<GoogleCloudOptions>() ?? new();
var storage = config.GetSection("Storage").Get<StorageOptions>() ?? new();

// ---- Dịch + giọng đọc:
if (google.Enabled)
{
    builder.Services.AddHttpClient<ITranslationService, GoogleTranslationService>();
    builder.Services.AddHttpClient<ITtsService, GoogleTtsService>();
}
else
{
    var provider = config.GetValue("Translation:Provider", "MyMemory");
    if (string.Equals(provider, "MyMemory", StringComparison.OrdinalIgnoreCase))
        builder.Services.AddHttpClient<ITranslationService, MyMemoryTranslationService>(c => c.Timeout = TimeSpan.FromSeconds(30));
    else
        builder.Services.AddSingleton<ITranslationService, MockTranslationService>();
    builder.Services.AddSingleton<ITtsService, MockTtsService>();
}

// ---- Lưu ảnh/âm thanh: Supabase nếu có cấu hình, không thì lưu trong wwwroot/media ----
if (!string.IsNullOrWhiteSpace(storage.Url) && !string.IsNullOrWhiteSpace(storage.Key))
    builder.Services.AddHttpClient<IFileStorage, SupabaseFileStorage>();
else
    builder.Services.AddSingleton<IFileStorage, LocalFileStorage>();

builder.Services.AddSingleton<TranslationQueue>();
builder.Services.AddHostedService<TranslationWorker>();
builder.Services.AddScoped<TranslationPipeline>();
builder.Services.AddScoped<ContentResolver>();
builder.Services.AddScoped<DataImporter>();
builder.Services.AddScoped<QrService>();
builder.Services.AddHttpContextAccessor();

// ---- Trang Admin: đăng nhập bằng cookie, 2 vai trò ADMIN / EDITOR ----
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(o =>
    {
        o.LoginPath = "/admin/account/login";
        o.LogoutPath = "/admin/account/logout";
        o.AccessDeniedPath = "/admin/account/denied";
        o.ExpireTimeSpan = TimeSpan.FromHours(8);
        o.SlidingExpiration = true;
        // Gọi /api/... khi chưa đăng nhập thì trả 401 thay vì chuyển hướng sang trang đăng nhập.
        o.Events.OnRedirectToLogin = ctx =>
        {
            if (ctx.Request.Path.StartsWithSegments("/api")) ctx.Response.StatusCode = 401;
            else ctx.Response.Redirect(ctx.RedirectUri);
            return Task.CompletedTask;
        };
    });
builder.Services.AddAuthorization();

builder.Services.AddControllersWithViews();
// Không mã hoá chữ tiếng Việt / Trung / Hàn / Nhật thành &#x...; trong HTML.
builder.Services.Configure<Microsoft.Extensions.WebEncoders.WebEncoderOptions>(o =>
    o.TextEncoderSettings = new System.Text.Encodings.Web.TextEncoderSettings(System.Text.Unicode.UnicodeRanges.All));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new() { Title = "CampusGuide API", Version = "v1" });
    // Chỉ liệt kê API cho app, bỏ các trang MVC (Admin, trang QR).
    o.DocInclusionPredicate((_, api) => api.RelativePath?.StartsWith("api/") == true);
    var xml = Path.Combine(AppContext.BaseDirectory, "CampusGuide.Web.xml");
    if (File.Exists(xml)) o.IncludeXmlComments(xml);
});
builder.Services.AddCors(o => o.AddPolicy("app", p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

// Tự tạo bảng (tương đương "dotnet ef database update") và nạp dữ liệu mẫu khi khởi động.
if (config.GetValue("Database:AutoMigrate", true))
{
    using var scope = app.Services.CreateScope();
    await scope.ServiceProvider.GetRequiredService<AppDbContext>().Database.MigrateAsync();
    await DbSeeder.SeedAsync(scope.ServiceProvider);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/error");
}
app.UseSwagger();
app.UseSwaggerUI();

app.UseStaticFiles();
app.UseRouting();
app.UseCors("app");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute("areas", "{area:exists}/{controller=Home}/{action=Index}/{id?}");
app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");

app.Run();

// Cho phép dự án kiểm thử (nếu có) dùng WebApplicationFactory<Program>.
public partial class Program { }
