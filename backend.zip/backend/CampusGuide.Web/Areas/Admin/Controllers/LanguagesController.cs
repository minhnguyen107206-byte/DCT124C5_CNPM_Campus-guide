using CampusGuide.Web.Areas.Admin.Models;
using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>Quản lý ngôn ngữ, giọng đọc, tốc độ đọc và ngôn ngữ dự phòng (quản trị viên).</summary>
[Authorize(Roles = AdminRole)]
public class LanguagesController(AppDbContext db, TranslationPipeline pipeline, ITtsService tts) : AdminController
{
    /// <summary>Câu đọc thử giọng cho từng ngôn ngữ (ngôn ngữ khác dùng tiếng Anh).</summary>
    private static readonly Dictionary<string, string> Samples = new()
    {
        ["vi"] = "Chào mừng bạn đến với Trường Đại học Sài Gòn.",
        ["en"] = "Welcome to Saigon University.",
        ["zh"] = "欢迎来到西贡大学。",
        ["ko"] = "사이공 대학교에 오신 것을 환영합니다.",
        ["ja"] = "サイゴン大学へようこそ。",
        ["fr"] = "Bienvenue à l'Université de Saigon."
    };

    public async Task<IActionResult> Index()
    {
        ViewBag.Approved = await db.Translations.Where(t => t.Status == TranslationStatus.Approved)
            .GroupBy(t => t.LanguageCode).Select(g => new { g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Count);
        ViewBag.ContentCount = await db.Contents.CountAsync();
        return View(await db.Languages.OrderByDescending(l => l.Code == Language.SourceCode).ThenBy(l => l.Name).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> Edit(string? id)
    {
        if (id == null) return View(new LanguageEditViewModel { IsNew = true });
        var l = await db.Languages.FindAsync(id);
        if (l == null) return NotFound();
        return View(new LanguageEditViewModel
        {
            Code = l.Code, Name = l.Name, NativeName = l.NativeName, TtsVoice = l.TtsVoice,
            TtsSpeed = l.TtsSpeed, IsActive = l.IsActive, IsFallback = l.IsFallback
        });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(LanguageEditViewModel vm)
    {
        vm.Code = vm.Code.Trim();
        var existing = await db.Languages.FindAsync(vm.Code);
        if (vm.IsNew && existing != null) ModelState.AddModelError(nameof(vm.Code), "Mã ngôn ngữ đã có.");
        if (!vm.IsNew && existing == null) return NotFound();
        if (vm.Code == Language.SourceCode && !vm.IsActive)
            ModelState.AddModelError(nameof(vm.IsActive), "Không thể tắt tiếng Việt vì đây là ngôn ngữ của nội dung gốc.");
        if (vm.IsFallback && !vm.IsActive)
            ModelState.AddModelError(nameof(vm.IsFallback), "Ngôn ngữ dự phòng phải đang bật.");
        if (!ModelState.IsValid) return View(vm);

        var lang = existing ?? new Language { Code = vm.Code };
        var turnedOn = vm.IsActive && (existing == null || !existing.IsActive);
        var voiceChanged = existing != null && (existing.TtsVoice != vm.TtsVoice.Trim() || existing.TtsSpeed != vm.TtsSpeed);

        if (vm.IsFallback && !lang.IsFallback)
        {
            // Chỉ một ngôn ngữ dự phòng: bỏ cờ của ngôn ngữ cũ trước (ràng buộc UNIQUE ... WHERE is_fallback).
            await db.Languages.Where(l => l.IsFallback).ExecuteUpdateAsync(s => s.SetProperty(l => l.IsFallback, false));
        }

        lang.Name = vm.Name.Trim();
        lang.NativeName = vm.NativeName.Trim();
        lang.TtsVoice = vm.TtsVoice.Trim();
        lang.TtsSpeed = vm.TtsSpeed;
        lang.IsActive = vm.IsActive;
        lang.IsFallback = vm.IsFallback;
        if (existing == null) db.Languages.Add(lang);
        await db.SaveChangesAsync();

        if (turnedOn) await pipeline.EnqueueAllAsync();
        if (voiceChanged)
        {
            // Giọng/tốc độ đổi thì mã băm audio đổi: bỏ liên kết audio cũ, duyệt lại hoặc bấm "Sinh lại audio".
            await db.Translations.Where(t => t.LanguageCode == lang.Code)
                .ExecuteUpdateAsync(s => s.SetProperty(t => t.AudioId, (long?)null));
            await pipeline.EnqueueAllAsync();
        }

        Success(turnedOn
            ? $"Đã bật {lang.Name}. Toàn bộ nội dung đang được dịch sang ngôn ngữ này."
            : $"Đã lưu {lang.Name}.");
        return RedirectToAction(nameof(Index));
    }

    /// <summary>Dịch toàn bộ nội dung còn thiếu sang mọi ngôn ngữ đang bật.</summary>
    [HttpPost]
    public async Task<IActionResult> TranslateAll()
    {
        await pipeline.EnqueueAllAsync();
        Success("Đã đưa toàn bộ nội dung vào hàng đợi dịch.");
        return RedirectToAction(nameof(Index));
    }

    /// <summary>Nghe thử giọng. Trả MP3; chưa cấu hình Google TTS thì trả 204 để trình duyệt tự đọc.</summary>
    [HttpPost]
    public async Task<IActionResult> Preview(string voice, decimal speed, string code)
    {
        var text = Samples.GetValueOrDefault(code) ?? Samples["en"];
        try
        {
            var result = await tts.SynthesizeAsync(text, voice, speed);
            return result == null ? NoContent() : File(result.Mp3, "audio/mpeg");
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(ex.Message);
        }
    }
}
