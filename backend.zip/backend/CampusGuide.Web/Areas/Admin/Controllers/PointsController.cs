using System.Text;
using CampusGuide.Web.Areas.Admin.Models;
using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>Quản lý điểm thuyết minh, nội dung gốc tiếng Việt và mã QR.</summary>
public class PointsController(
    AppDbContext db,
    TranslationPipeline pipeline,
    DataImporter importer,
    QrService qr,
    IFileStorage storage,
    IWebHostEnvironment env,
    Microsoft.Extensions.Options.IOptions<AppOptions> appOptions) : AdminController
{
    private static readonly string[] ImageTypes = { "image/jpeg", "image/png", "image/webp" };

    public async Task<IActionResult> Index(string? q, int? categoryId, PointStatus? status)
    {
        var query = db.Points.Include(p => p.Category).Include(p => p.Content!).ThenInclude(c => c.Translations).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(p => EF.Functions.ILike(p.Name, $"%{q.Trim()}%") || EF.Functions.ILike(p.Code, $"%{q.Trim()}%"));
        if (categoryId != null) query = query.Where(p => p.CategoryId == categoryId);
        if (status != null) query = query.Where(p => p.Status == status);

        ViewBag.Q = q;
        ViewBag.CategoryId = categoryId;
        ViewBag.Status = status;
        ViewBag.Categories = await CategoryListAsync(categoryId);
        return View(await query.OrderBy(p => p.Code).AsNoTracking().ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> Edit(long? id)
    {
        ViewBag.Categories = await CategoryListAsync(null);
        if (id == null) return View(new PointEditViewModel());

        var p = await db.Points.Include(x => x.Content!).ThenInclude(c => c.Translations).ThenInclude(t => t.Language)
            .FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return NotFound();
        return View(new PointEditViewModel
        {
            Id = p.Id, Code = p.Code, Name = p.Name, CategoryId = p.CategoryId,
            Latitude = p.Latitude, Longitude = p.Longitude, RadiusM = p.RadiusM, Priority = p.Priority,
            FloorInfo = p.FloorInfo, OpeningHours = p.OpeningHours, Status = p.Status,
            SourceText = p.Content!.SourceText, ImageUrl = p.ImageUrl, QrToken = p.QrToken,
            ContentVersion = p.Content.Version,
            Translations = p.Content.Translations.OrderBy(t => t.LanguageCode).ToList()
        });
    }

    [HttpPost]
    [RequestSizeLimit(10_000_000)]
    public async Task<IActionResult> Edit(PointEditViewModel vm)
    {
        var code = vm.Code.Trim().ToUpperInvariant();
        if (await db.Points.AnyAsync(p => p.Code == code && p.Id != vm.Id))
            ModelState.AddModelError(nameof(vm.Code), "Mã điểm đã tồn tại.");
        if (!appOptions.Value.IsInsideCampus(vm.Latitude, vm.Longitude))
            ModelState.AddModelError(nameof(vm.Latitude), $"Vị trí nằm ngoài khuôn viên (quá {appOptions.Value.CampusRadiusM} m tính từ tâm trường). Kiểm tra lại vĩ độ/kinh độ có bị đảo không.");
        if (vm.Image != null && !ImageTypes.Contains(vm.Image.ContentType))
            ModelState.AddModelError(nameof(vm.Image), "Ảnh phải là JPG, PNG hoặc WEBP.");
        if (!ModelState.IsValid)
        {
            ViewBag.Categories = await CategoryListAsync(null);
            return View(vm);
        }

        Point? point;
        if (vm.Id == null)
        {
            var content = await pipeline.SaveSourceAsync(null, vm.SourceText, CurrentUserId);
            point = new Point { ContentId = content.Id, QrToken = Hashing.NewQrToken(), CreatedBy = CurrentUserId };
            db.Points.Add(point);
        }
        else
        {
            point = await db.Points.Include(p => p.Content).FirstOrDefaultAsync(p => p.Id == vm.Id);
            if (point == null) return NotFound();
            await pipeline.SaveSourceAsync(point.Content, vm.SourceText, CurrentUserId);
        }

        point.Code = code;
        point.Name = vm.Name.Trim();
        point.CategoryId = vm.CategoryId;
        point.Location = Point.MakeLocation(vm.Latitude, vm.Longitude);
        point.RadiusM = vm.RadiusM;
        point.Priority = vm.Priority;
        point.FloorInfo = vm.FloorInfo?.Trim();
        point.OpeningHours = vm.OpeningHours?.Trim();
        point.Status = vm.Status;
        point.UpdatedAt = DateTime.UtcNow;

        if (vm.Image is { Length: > 0 })
        {
            using var ms = new MemoryStream();
            await vm.Image.CopyToAsync(ms);
            var ext = Path.GetExtension(vm.Image.FileName).ToLowerInvariant();
            point.ImageUrl = await storage.SaveAsync($"points/{code}-{DateTime.UtcNow:yyyyMMddHHmmss}{ext}", ms.ToArray(), vm.Image.ContentType);
        }

        await db.SaveChangesAsync();
        Success(vm.Id == null
            ? $"Đã thêm điểm {point.Code}. Bản dịch đang được tạo, xem ở mục Bản dịch."
            : $"Đã lưu điểm {point.Code}. Nếu nội dung đổi, bản dịch cũ chuyển sang \"Cần dịch lại\" và đang được dịch lại.");
        return RedirectToAction(nameof(Edit), new { id = point.Id });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(long id)
    {
        var p = await db.Points.FindAsync(id);
        if (p == null) return NotFound();
        if (await db.PlayLogs.AnyAsync(l => l.PointId == id) || await db.TourStops.AnyAsync(s => s.PointId == id))
        {
            // Giữ lịch sử thống kê và tour: chỉ ẩn điểm.
            p.Status = PointStatus.Hidden;
            await db.SaveChangesAsync();
            Success($"Điểm {p.Code} đã có lượt nghe hoặc nằm trong tour nên được chuyển sang Ẩn thay vì xoá.");
            return RedirectToAction(nameof(Index));
        }
        var content = await db.Contents.FindAsync(p.ContentId);
        db.Points.Remove(p);
        await db.SaveChangesAsync();
        if (content != null && !await db.Announcements.AnyAsync(a => a.ContentId == content.Id))
        {
            db.Contents.Remove(content);
            await db.SaveChangesAsync();
        }
        Success($"Đã xoá điểm {p.Code}.");
        return RedirectToAction(nameof(Index));
    }

    // ---------- Mã QR ----------

    /// <summary>Ảnh PNG mã QR của điểm. ?download=true để tải về.</summary>
    public async Task<IActionResult> Qr(long id, bool download = false)
    {
        var p = await db.Points.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return NotFound();
        var png = qr.RenderPng(p.QrToken);
        return download ? File(png, "image/png", $"QR-{p.Code}.png") : File(png, "image/png");
    }

    /// <summary>Trang in mã QR (nhiều điểm mỗi trang A4). ids rỗng = in tất cả điểm đang hiện.</summary>
    public async Task<IActionResult> PrintQr(long[]? ids)
    {
        var query = db.Points.AsNoTracking().Where(p => p.Status == PointStatus.Active);
        if (ids is { Length: > 0 }) query = query.Where(p => ids.Contains(p.Id));
        var points = await query.OrderBy(p => p.Code).ToListAsync();
        ViewBag.Urls = points.ToDictionary(p => p.Id, p => qr.BuildUrl(p.QrToken));
        return View(points);
    }

    /// <summary>Đổi token QR (khi mã cũ bị dán sai chỗ hoặc bị sao chép). Mã đã in trước đó sẽ hết hiệu lực.</summary>
    [HttpPost]
    public async Task<IActionResult> RegenerateQr(long id)
    {
        var p = await db.Points.FindAsync(id);
        if (p == null) return NotFound();
        p.QrToken = Hashing.NewQrToken();
        p.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        Success("Đã tạo mã QR mới. Nhớ in lại và thay mã cũ.");
        return RedirectToAction(nameof(Edit), new { id });
    }

    // ---------- Nhập / xuất CSV ----------

    [HttpGet]
    public IActionResult Import() => View();

    [HttpPost]
    [RequestSizeLimit(5_000_000)]
    public async Task<IActionResult> Import(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            Error("Chọn file CSV.");
            return View();
        }
        using var reader = new StreamReader(file.OpenReadStream(), Encoding.UTF8);
        var result = await importer.ImportPointsAsync(await reader.ReadToEndAsync(), CurrentUserId);
        return View("ImportResult", result);
    }

    /// <summary>Tải file mẫu nhập điểm (UTF-8 có BOM để Excel hiển thị đúng tiếng Việt).</summary>
    public IActionResult Template()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "Data", "Seed", "diem.csv");
        if (!System.IO.File.Exists(path)) path = Path.Combine(env.ContentRootPath, "Data", "Seed", "diem.csv");
        return PhysicalFile(path, "text/csv", "mau-nhap-diem.csv");
    }

    /// <summary>Xuất toàn bộ điểm ra CSV cùng định dạng file nhập (để sao lưu hoặc sửa hàng loạt bằng Excel).</summary>
    public async Task<IActionResult> Export()
    {
        var points = await db.Points.AsNoTracking().Include(p => p.Category).Include(p => p.Content).OrderBy(p => p.Code).ToListAsync();
        var sb = new StringBuilder("ma,ten,loai,vi_do,kinh_do,ban_kinh_m,uu_tien,tang_phong,gio_mo_cua,anh,noi_dung\n");
        foreach (var p in points)
        {
            sb.AppendJoin(',', new[]
            {
                p.Code, p.Name, p.Category?.Name ?? "", p.Latitude.ToString("0.000000", System.Globalization.CultureInfo.InvariantCulture),
                p.Longitude.ToString("0.000000", System.Globalization.CultureInfo.InvariantCulture), p.RadiusM.ToString(), p.Priority.ToString(),
                p.FloorInfo ?? "", p.OpeningHours ?? "", p.ImageUrl ?? "", p.Content?.SourceText ?? ""
            }.Select(Quote)).Append('\n');
        }
        var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
        return File(bytes, "text/csv", $"diem-{DateTime.Now:yyyyMMdd}.csv");
    }

    private static string Quote(string s) =>
        s.IndexOfAny(new[] { ',', '"', '\n', ';' }) >= 0 ? $"\"{s.Replace("\"", "\"\"")}\"" : s;

    private async Task<SelectList> CategoryListAsync(int? selected) =>
        new(await db.Categories.OrderBy(c => c.Name).ToListAsync(), "Id", "Name", selected);
}
