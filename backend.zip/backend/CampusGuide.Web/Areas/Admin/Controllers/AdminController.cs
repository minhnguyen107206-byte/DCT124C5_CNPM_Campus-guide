using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>Lớp cha của các trang Admin: bắt đăng nhập, lấy id người dùng, hiện thông báo một lần (TempData).</summary>
[Area("Admin")]
[Authorize]
[AutoValidateAntiforgeryToken]
public abstract class AdminController : Controller
{
    public const string AdminRole = "ADMIN";

    protected long CurrentUserId => long.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    protected void Success(string message) => TempData["flash-success"] = message;
    protected void Error(string message) => TempData["flash-error"] = message;
}
