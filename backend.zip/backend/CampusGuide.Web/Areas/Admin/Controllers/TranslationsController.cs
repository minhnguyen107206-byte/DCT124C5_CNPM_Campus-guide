using CampusGuide.Web.Areas.Admin.Models;
using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>Duyệt, sửa, từ chối bản dịch; nghe thử; dịch lại; sinh lại audio.</summary>
public class TranslationsController(AppDbContext db, TranslationPipeline pipeline, TranslationQueue queue) : AdminController
{
    private const int PageSize = 30;

    /// <summary>Mặc định mở danh sách "Chờ duyệt". status=all để xem tất cả.</summary>
    public async Task<IActionResult> Index(string? status = "Pending", string? lang = null, string? q = null, int page = 1)
    {
        var query = db.Translations.AsNoTracking()
            .Include(t => t.Content).Include(t => t.Language).Include(t => t.Audio)
            .Where(t => t.LanguageCode != Language.SourceCode);

        if (Enum.TryParse<TranslationStatus>(status, true, out var st)) query = query.Where(t => t.Status == st);
        if (!string.IsNullOrEmpty(lang)) query = query.Where(t => t.LanguageCode == lang);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var pattern = $"%{q.Trim()}%";
            var contentIds = db.Points.Where(p => EF.Functions.ILike(p.Name, pattern) || EF.Functions.ILike(p.Code, pattern)).Select(p => p.ContentId)
                .Union(db.Tours.Where(t => EF.Functions.ILike(t.Name, pattern)).Select(t => t.ContentId))
                .Union(db.Announcements.Where(a => EF.Functions.ILike(a.Title, pattern)).Select(a => a.ContentId));
            query = query.Where(t => contentIds.Contains(t.ContentId) || EF.Functions.ILike(t.TranslatedText!, pattern));
        }

        var total = await query.CountAsync();
        var items = await query.OrderBy(t => t.ContentId).ThenBy(t => t.LanguageCode)
            .Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        ViewBag.Counts = await db.Translations.Where(t => t.LanguageCode != Language.SourceCode)
            .GroupBy(t => t.Status).Select(g => new { g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Count);
        ViewBag.Languages = await db.Languages.Where(l => l.Code != Language.SourceCode).OrderBy(l => l.Name).ToListAsync();
        ViewBag.Status = status;
        ViewBag.Lang = lang;
        ViewBag.Q = q;
        ViewBag.Page = page;
        ViewBag.PageCount = (int)Math.Ceiling(total / (double)PageSize);
        ViewBag.QueueCount = queue.Count;
        return View(await WithOwnersAsync(items));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(long id)
    {
        var t = await db.Translations
            .Include(x => x.Content).Include(x => x.Language).Include(x => x.Audio).Include(x => x.ReviewedByUser)
            .AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (t == null) return NotFound();
        ViewBag.Siblings = await db.Translations.AsNoTracking().Include(x => x.Language)
            .Where(x => x.ContentId == t.ContentId && x.Id != t.Id).OrderBy(x => x.LanguageCode).ToListAsync();
        return View((await WithOwnersAsync(new List<Translation> { t }))[0]);
    }

    /// <summary>Lưu bản sửa tay. Nút "Lưu và duyệt" gửi approve=true.</summary>
    [HttpPost]
    public async Task<IActionResult> Save(long id, string translatedText, bool approve = false)
    {
        if (string.IsNullOrWhiteSpace(translatedText))
        {
            Error("Bản dịch không được để trống.");
            return RedirectToAction(nameof(Edit), new { id });
        }
        await pipeline.SaveHumanEditAsync(id, translatedText, CurrentUserId, approve);
        Success(approve ? "Đã lưu và duyệt bản dịch." : "Đã lưu bản dịch, đang chờ duyệt.");
        return RedirectToAction(nameof(Edit), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> Approve(long id, string? returnUrl)
    {
        try
        {
            await pipeline.ApproveAsync(id, CurrentUserId);
            Success("Đã duyệt bản dịch.");
        }
        catch (InvalidOperationException ex)
        {
            Error(ex.Message);
        }
        return Back(returnUrl, id);
    }

    [HttpPost]
    public async Task<IActionResult> Reject(long id, string? reason, string? returnUrl)
    {
        if (string.IsNullOrWhiteSpace(reason))
        {
            Error("Nhập lý do từ chối để người sửa biết cần chỉnh gì.");
            return RedirectToAction(nameof(Edit), new { id });
        }
        await pipeline.RejectAsync(id, CurrentUserId, reason.Trim());
        Success("Đã từ chối bản dịch.");
        return Back(returnUrl, id);
    }

    [HttpPost]
    public async Task<IActionResult> Retranslate(long id)
    {
        await pipeline.RetranslateAsync(id);
        Success("Đã dịch lại bằng máy. Kiểm tra rồi duyệt.");
        return RedirectToAction(nameof(Edit), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> RegenerateAudio(long id)
    {
        try
        {
            await pipeline.RegenerateAudioAsync(id);
            Success("Đã sinh lại audio.");
        }
        catch (Exception ex) when (ex is InvalidOperationException or HttpRequestException)
        {
            Error(ex.Message);
        }
        return RedirectToAction(nameof(Edit), new { id });
    }

    /// <summary>Duyệt nhanh nhiều bản dịch được chọn ở danh sách.</summary>
    [HttpPost]
    public async Task<IActionResult> ApproveMany(long[] ids, string? returnUrl)
    {
        var ok = 0;
        foreach (var id in ids)
        {
            try { await pipeline.ApproveAsync(id, CurrentUserId); ok++; }
            catch (InvalidOperationException) { }
        }
        Success($"Đã duyệt {ok}/{ids.Length} bản dịch.");
        return Url.IsLocalUrl(returnUrl) ? Redirect(returnUrl) : RedirectToAction(nameof(Index));
    }

    private IActionResult Back(string? returnUrl, long id) =>
        Url.IsLocalUrl(returnUrl) ? Redirect(returnUrl) : RedirectToAction(nameof(Edit), new { id });

    /// <summary>Gắn tên điểm/tour/thông báo sở hữu nội dung để biên tập viên biết đang duyệt cái gì.</summary>
    private async Task<List<TranslationRow>> WithOwnersAsync(List<Translation> items)
    {
        var ids = items.Select(t => t.ContentId).Distinct().ToList();
        var points = await db.Points.Where(p => ids.Contains(p.ContentId)).Select(p => new { p.ContentId, p.Id, p.Code, p.Name }).ToListAsync();
        var tours = await db.Tours.Where(t => ids.Contains(t.ContentId)).Select(t => new { t.ContentId, t.Name }).ToListAsync();
        var anns = await db.Announcements.Where(a => ids.Contains(a.ContentId)).Select(a => new { a.ContentId, a.Title }).ToListAsync();

        return items.Select(t =>
        {
            var p = points.FirstOrDefault(x => x.ContentId == t.ContentId);
            if (p != null) return new TranslationRow(t, $"Điểm {p.Code} · {p.Name}", Url.Action("Edit", "Points", new { id = p.Id }));
            var tour = tours.FirstOrDefault(x => x.ContentId == t.ContentId);
            if (tour != null) return new TranslationRow(t, $"Tour · {tour.Name}", null);
            var a = anns.FirstOrDefault(x => x.ContentId == t.ContentId);
            if (a != null) return new TranslationRow(t, $"Thông báo · {a.Title}", null);
            return new TranslationRow(t, $"Nội dung #{t.ContentId}", null);
        }).ToList();
    }
}
