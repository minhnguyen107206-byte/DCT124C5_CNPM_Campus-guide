using System.Text;
using CampusGuide.Web.Areas.Admin.Models;
using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>
/// Bảng thuật ngữ (quản trị viên). Thêm/sửa thuật ngữ thì các nội dung có chứa thuật ngữ đó
/// được dịch lại bằng máy (bản đã sửa tay giữ nguyên).
/// </summary>
[Authorize(Roles = AdminRole)]
public class GlossaryController(AppDbContext db, TranslationPipeline pipeline, DataImporter importer) : AdminController
{
    public async Task<IActionResult> Index(string? lang, string? q)
    {
        var query = db.GlossaryTerms.AsNoTracking().Include(g => g.Language).AsQueryable();
        if (!string.IsNullOrEmpty(lang)) query = query.Where(g => g.LanguageCode == lang);
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(g => EF.Functions.ILike(g.SourceTerm, $"%{q.Trim()}%") || EF.Functions.ILike(g.TargetTerm, $"%{q.Trim()}%"));
        ViewBag.Lang = lang;
        ViewBag.Q = q;
        ViewBag.Languages = await LanguageListAsync(lang);
        return View(await query.OrderBy(g => g.SourceTerm).ThenBy(g => g.LanguageCode).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> Edit(long? id)
    {
        ViewBag.Languages = await LanguageListAsync(null);
        if (id == null) return View(new GlossaryEditViewModel());
        var g = await db.GlossaryTerms.FindAsync(id);
        if (g == null) return NotFound();
        return View(new GlossaryEditViewModel { Id = g.Id, SourceTerm = g.SourceTerm, LanguageCode = g.LanguageCode, TargetTerm = g.TargetTerm, Note = g.Note });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(GlossaryEditViewModel vm)
    {
        var source = vm.SourceTerm.Trim();
        if (await db.GlossaryTerms.AnyAsync(g => g.SourceTerm == source && g.LanguageCode == vm.LanguageCode && g.Id != vm.Id))
            ModelState.AddModelError(nameof(vm.SourceTerm), "Thuật ngữ này đã có cho ngôn ngữ đã chọn.");
        if (vm.LanguageCode == Language.SourceCode)
            ModelState.AddModelError(nameof(vm.LanguageCode), "Chọn ngôn ngữ đích khác tiếng Việt.");
        if (!ModelState.IsValid)
        {
            ViewBag.Languages = await LanguageListAsync(null);
            return View(vm);
        }

        var term = vm.Id == null ? new GlossaryTerm() : await db.GlossaryTerms.FindAsync(vm.Id);
        if (term == null) return NotFound();
        if (vm.Id == null) db.GlossaryTerms.Add(term);
        var oldSource = term.SourceTerm;
        term.SourceTerm = source;
        term.LanguageCode = vm.LanguageCode;
        term.TargetTerm = vm.TargetTerm.Trim();
        term.Note = string.IsNullOrWhiteSpace(vm.Note) ? null : vm.Note.Trim();
        await db.SaveChangesAsync();

        var n = await pipeline.EnqueueContainingAsync(source);
        if (oldSource != "" && oldSource != source) n += await pipeline.EnqueueContainingAsync(oldSource);
        Success($"Đã lưu thuật ngữ. {n} nội dung có chứa thuật ngữ đang được dịch lại.");
        return RedirectToAction(nameof(Index), new { lang = vm.LanguageCode });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(long id)
    {
        var term = await db.GlossaryTerms.FindAsync(id);
        if (term == null) return NotFound();
        db.GlossaryTerms.Remove(term);
        await db.SaveChangesAsync();
        Success($"Đã xoá thuật ngữ \"{term.SourceTerm}\" ({term.LanguageCode}).");
        return RedirectToAction(nameof(Index), new { lang = term.LanguageCode });
    }

    [HttpPost]
    [RequestSizeLimit(2_000_000)]
    public async Task<IActionResult> Import(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            Error("Chọn file CSV.");
            return RedirectToAction(nameof(Index));
        }
        using var reader = new StreamReader(file.OpenReadStream(), Encoding.UTF8);
        var r = await importer.ImportGlossaryAsync(await reader.ReadToEndAsync());
        var msg = $"Nhập xong: thêm {r.Added}, cập nhật {r.Updated}.";
        if (r.Errors.Count > 0) Error(msg + " Lỗi: " + string.Join(" ", r.Errors.Take(10)));
        else Success(msg);
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Export()
    {
        var sb = new StringBuilder("thuat_ngu,ngon_ngu,cach_viet_chuan,ghi_chu\n");
        foreach (var g in await db.GlossaryTerms.AsNoTracking().OrderBy(g => g.SourceTerm).ThenBy(g => g.LanguageCode).ToListAsync())
            sb.AppendJoin(',', new[] { g.SourceTerm, g.LanguageCode, g.TargetTerm, g.Note ?? "" }.Select(Quote)).Append('\n');
        var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
        return File(bytes, "text/csv", "thuat-ngu.csv");
    }

    private static string Quote(string s) =>
        s.IndexOfAny(new[] { ',', '"', '\n', ';' }) >= 0 ? $"\"{s.Replace("\"", "\"\"")}\"" : s;

    private async Task<SelectList> LanguageListAsync(string? selected) =>
        new(await db.Languages.Where(l => l.Code != Language.SourceCode).OrderBy(l => l.Name)
            .Select(l => new { l.Code, Label = l.Name + " (" + l.Code + ")" }).ToListAsync(), "Code", "Label", selected);
}
