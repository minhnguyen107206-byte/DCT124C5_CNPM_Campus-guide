using System.Security.Claims;
using CampusGuide.Web.Areas.Admin.Models;
using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>Đăng nhập, đăng xuất, đổi mật khẩu (mọi cán bộ) và quản lý tài khoản, phân quyền (chỉ quản trị viên).</summary>
public class AccountController(AppDbContext db) : AdminController
{
    // ---------- Đăng nhập / đăng xuất ----------

    [AllowAnonymous, HttpGet]
    public IActionResult Login(string? returnUrl) =>
        User.Identity?.IsAuthenticated == true
            ? RedirectToAction("Index", "Home")
            : View(new LoginViewModel { ReturnUrl = returnUrl });

    [AllowAnonymous, HttpPost]
    public async Task<IActionResult> Login(LoginViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var email = vm.Email.Trim().ToLowerInvariant();
        var user = await db.Users.FirstOrDefaultAsync(u => u.Email == email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(vm.Password, user.PasswordHash))
        {
            ModelState.AddModelError("", "Email hoặc mật khẩu không đúng.");
            return View(vm);
        }
        if (user.Status == UserStatus.Locked)
        {
            ModelState.AddModelError("", "Tài khoản đã bị khoá. Liên hệ quản trị viên.");
            return View(vm);
        }

        user.LastLoginAt = DateTime.UtcNow;
        await db.SaveChangesAsync();

        var identity = new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.FullName),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role.ToString().ToUpperInvariant())
        }, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(new ClaimsPrincipal(identity));

        return Url.IsLocalUrl(vm.ReturnUrl) ? Redirect(vm.ReturnUrl) : RedirectToAction("Index", "Home");
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync();
        return RedirectToAction(nameof(Login));
    }

    [AllowAnonymous]
    public IActionResult Denied() => View();

    // ---------- Đổi mật khẩu ----------

    [HttpGet]
    public IActionResult ChangePassword() => View(new ChangePasswordViewModel());

    [HttpPost]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var user = await db.Users.FindAsync(CurrentUserId);
        if (user == null) return NotFound();
        if (!BCrypt.Net.BCrypt.Verify(vm.CurrentPassword, user.PasswordHash))
        {
            ModelState.AddModelError(nameof(vm.CurrentPassword), "Mật khẩu hiện tại không đúng.");
            return View(vm);
        }
        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(vm.NewPassword);
        await db.SaveChangesAsync();
        Success("Đã đổi mật khẩu.");
        return RedirectToAction("Index", "Home");
    }

    // ---------- Quản lý tài khoản (quản trị viên) ----------

    [Authorize(Roles = AdminRole)]
    public async Task<IActionResult> Users() =>
        View(await db.Users.OrderBy(u => u.Role).ThenBy(u => u.FullName).ToListAsync());

    [Authorize(Roles = AdminRole), HttpGet]
    public async Task<IActionResult> EditUser(long? id)
    {
        if (id == null) return View(new UserEditViewModel());
        var u = await db.Users.FindAsync(id);
        if (u == null) return NotFound();
        return View(new UserEditViewModel { Id = u.Id, FullName = u.FullName, Email = u.Email, Role = u.Role, Status = u.Status });
    }

    [Authorize(Roles = AdminRole), HttpPost]
    public async Task<IActionResult> EditUser(UserEditViewModel vm)
    {
        var email = vm.Email.Trim().ToLowerInvariant();
        if (vm.Id == null && string.IsNullOrWhiteSpace(vm.Password))
            ModelState.AddModelError(nameof(vm.Password), "Nhập mật khẩu cho tài khoản mới.");
        if (await db.Users.AnyAsync(u => u.Email == email && u.Id != vm.Id))
            ModelState.AddModelError(nameof(vm.Email), "Email đã được dùng cho tài khoản khác.");
        if (vm.Id == CurrentUserId && (vm.Role != UserRole.Admin || vm.Status != UserStatus.Active))
            ModelState.AddModelError("", "Không thể tự hạ quyền hoặc tự khoá tài khoản đang đăng nhập.");
        if (!ModelState.IsValid) return View(vm);

        var user = vm.Id == null ? new User() : await db.Users.FindAsync(vm.Id);
        if (user == null) return NotFound();
        if (vm.Id == null) db.Users.Add(user);

        user.FullName = vm.FullName.Trim();
        user.Email = email;
        user.Role = vm.Role;
        user.Status = vm.Status;
        if (!string.IsNullOrWhiteSpace(vm.Password))
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(vm.Password);
        await db.SaveChangesAsync();

        Success(vm.Id == null ? $"Đã tạo tài khoản {user.Email}." : $"Đã cập nhật tài khoản {user.Email}.");
        return RedirectToAction(nameof(Users));
    }

    [Authorize(Roles = AdminRole), HttpPost]
    public async Task<IActionResult> ToggleLock(long id)
    {
        var user = await db.Users.FindAsync(id);
        if (user == null) return NotFound();
        if (user.Id == CurrentUserId)
        {
            Error("Không thể tự khoá tài khoản đang đăng nhập.");
            return RedirectToAction(nameof(Users));
        }
        user.Status = user.Status == UserStatus.Active ? UserStatus.Locked : UserStatus.Active;
        await db.SaveChangesAsync();
        Success(user.Status == UserStatus.Locked ? $"Đã khoá {user.Email}." : $"Đã mở khoá {user.Email}.");
        return RedirectToAction(nameof(Users));
    }
}
