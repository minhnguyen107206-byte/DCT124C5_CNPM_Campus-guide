using CampusGuide.Web.Data;
using CampusGuide.Web.Models;
using CampusGuide.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusGuide.Web.Areas.Admin.Controllers;

/// <summary>Trang tổng quan sau khi đăng nhập.</summary>
public class HomeController(AppDbContext db, TranslationQueue queue, ITranslationService translator, ITtsService tts) : AdminController
{
    public async Task<IActionResult> Index()
    {
        ViewBag.PointCount = await db.Points.CountAsync();
        ViewBag.LanguageCount = await db.Languages.CountAsync(l => l.IsActive);
        ViewBag.GlossaryCount = await db.GlossaryTerms.CountAsync();
        ViewBag.StatusCounts = await db.Translations
            .Where(t => t.LanguageCode != Language.SourceCode)
            .GroupBy(t => t.Status)
            .Select(g => new { g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Count);
        ViewBag.QueueCount = queue.Count;
        ViewBag.Translator = translator.Name;
        ViewBag.Tts = tts.Name;
        return View();
    }
}
