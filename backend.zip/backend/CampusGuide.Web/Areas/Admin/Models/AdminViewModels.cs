using System.ComponentModel.DataAnnotations;
using CampusGuide.Web.Models;

namespace CampusGuide.Web.Areas.Admin.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Nhập email"), EmailAddress(ErrorMessage = "Email không hợp lệ")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Nhập mật khẩu"), DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

public class ChangePasswordViewModel
{
    [Required(ErrorMessage = "Nhập mật khẩu hiện tại"), DataType(DataType.Password)]
    public string CurrentPassword { get; set; } = "";

    [Required(ErrorMessage = "Nhập mật khẩu mới"), DataType(DataType.Password)]
    [MinLength(8, ErrorMessage = "Mật khẩu tối thiểu 8 ký tự")]
    [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d).+$", ErrorMessage = "Mật khẩu phải có cả chữ và số")]
    public string NewPassword { get; set; } = "";

    [Compare(nameof(NewPassword), ErrorMessage = "Nhập lại mật khẩu không khớp"), DataType(DataType.Password)]
    public string ConfirmPassword { get; set; } = "";
}

public class UserEditViewModel
{
    public long? Id { get; set; }

    [Required(ErrorMessage = "Nhập họ tên"), StringLength(100)]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Nhập email"), EmailAddress(ErrorMessage = "Email không hợp lệ"), StringLength(120)]
    public string Email { get; set; } = "";

    public UserRole Role { get; set; } = UserRole.Editor;
    public UserStatus Status { get; set; } = UserStatus.Active;

    /// <summary>Bắt buộc khi tạo mới; khi sửa để trống là giữ mật khẩu cũ.</summary>
    [MinLength(8, ErrorMessage = "Mật khẩu tối thiểu 8 ký tự"), DataType(DataType.Password)]
    public string? Password { get; set; }
}

public class PointEditViewModel
{
    public long? Id { get; set; }

    [Required(ErrorMessage = "Nhập mã điểm"), StringLength(20)]
    [RegularExpression(@"^[A-Za-z0-9_-]+$", ErrorMessage = "Mã chỉ gồm chữ không dấu, số, - và _")]
    public string Code { get; set; } = "";

    [Required(ErrorMessage = "Nhập tên điểm"), StringLength(150)]
    public string Name { get; set; } = "";

    [Range(1, int.MaxValue, ErrorMessage = "Chọn loại điểm")]
    public int CategoryId { get; set; }

    [Range(-90, 90, ErrorMessage = "Vĩ độ từ -90 đến 90")]
    public double Latitude { get; set; } = 10.7596;

    [Range(-180, 180, ErrorMessage = "Kinh độ từ -180 đến 180")]
    public double Longitude { get; set; } = 106.6822;

    [Range(10, 200, ErrorMessage = "Bán kính từ 10 đến 200 m")]
    public short RadiusM { get; set; } = 30;

    [Range(0, 100)]
    public short Priority { get; set; }

    [StringLength(255)]
    public string? FloorInfo { get; set; }

    [StringLength(100)]
    public string? OpeningHours { get; set; }

    public PointStatus Status { get; set; } = PointStatus.Active;

    [Required(ErrorMessage = "Nhập nội dung thuyết minh tiếng Việt")]
    [StringLength(Content.MaxLength, ErrorMessage = "Nội dung tối đa 3000 ký tự")]
    public string SourceText { get; set; } = "";

    public string? ImageUrl { get; set; }
    public IFormFile? Image { get; set; }

    // Chỉ để hiển thị khi sửa
    public string? QrToken { get; set; }
    public int ContentVersion { get; set; }
    public List<Translation> Translations { get; set; } = new();
}

public class LanguageEditViewModel
{
    public bool IsNew { get; set; }

    [Required(ErrorMessage = "Nhập mã ngôn ngữ"), StringLength(10)]
    [RegularExpression(@"^[a-z]{2,3}(-[A-Za-z]{2,4})?$", ErrorMessage = "Mã ISO 639-1, ví dụ en, zh, ko")]
    public string Code { get; set; } = "";

    [Required(ErrorMessage = "Nhập tên"), StringLength(50)]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Nhập tên bản ngữ"), StringLength(50)]
    public string NativeName { get; set; } = "";

    [Required(ErrorMessage = "Nhập mã giọng đọc"), StringLength(60)]
    public string TtsVoice { get; set; } = "";

    [Range(0.75, 1.25, ErrorMessage = "Tốc độ đọc từ 0.75 đến 1.25")]
    public decimal TtsSpeed { get; set; } = 1.00m;

    public bool IsActive { get; set; } = true;
    public bool IsFallback { get; set; }
}

public class GlossaryEditViewModel
{
    public long? Id { get; set; }

    [Required(ErrorMessage = "Nhập thuật ngữ tiếng Việt"), StringLength(150)]
    public string SourceTerm { get; set; } = "";

    [Required(ErrorMessage = "Chọn ngôn ngữ")]
    public string LanguageCode { get; set; } = "";

    [Required(ErrorMessage = "Nhập cách viết chuẩn"), StringLength(150)]
    public string TargetTerm { get; set; } = "";

    [StringLength(255)]
    public string? Note { get; set; }
}

/// <summary>Một dòng ở trang danh sách bản dịch: bản dịch + nội dung đó thuộc điểm/tour/thông báo nào.</summary>
public record TranslationRow(Translation Translation, string Owner, string? OwnerUrl);
