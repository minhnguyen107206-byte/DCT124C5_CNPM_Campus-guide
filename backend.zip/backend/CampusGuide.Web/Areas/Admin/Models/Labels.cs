using CampusGuide.Web.Models;

namespace CampusGuide.Web.Areas.Admin.Models;

/// <summary>Nhãn tiếng Việt và màu badge Bootstrap cho các trạng thái.</summary>
public static class Labels
{
    public static string Of(TranslationStatus s) => s switch
    {
        TranslationStatus.Pending => "Chờ duyệt",
        TranslationStatus.Approved => "Đã duyệt",
        TranslationStatus.Rejected => "Bị từ chối",
        TranslationStatus.Outdated => "Cần dịch lại",
        TranslationStatus.Failed => "Lỗi dịch",
        _ => s.ToString()
    };

    public static string Badge(TranslationStatus s) => s switch
    {
        TranslationStatus.Pending => "text-bg-warning",
        TranslationStatus.Approved => "text-bg-success",
        TranslationStatus.Rejected => "text-bg-danger",
        TranslationStatus.Outdated => "text-bg-secondary",
        TranslationStatus.Failed => "text-bg-dark",
        _ => "text-bg-light"
    };

    public static string Of(TranslationMethod m) => m == TranslationMethod.Machine ? "Dịch máy" : "Người sửa";
    public static string Of(PointStatus s) => s == PointStatus.Active ? "Đang hiện" : "Ẩn";
    public static string Of(UserRole r) => r == UserRole.Admin ? "Quản trị viên" : "Biên tập viên";
    public static string Of(UserStatus s) => s == UserStatus.Active ? "Hoạt động" : "Đã khoá";

    public static string Time(DateTime? utc) =>
        utc == null ? "" : TimeZoneInfo.ConvertTimeFromUtc(utc.Value, VietnamTz).ToString("dd/MM/yyyy HH:mm");

    private static readonly TimeZoneInfo VietnamTz = FindTz();

    private static TimeZoneInfo FindTz()
    {
        foreach (var id in new[] { "Asia/Ho_Chi_Minh", "SE Asia Standard Time" })
            if (TimeZoneInfo.TryFindSystemTimeZoneById(id, out var tz)) return tz;
        return TimeZoneInfo.CreateCustomTimeZone("ICT", TimeSpan.FromHours(7), "ICT", "ICT");
    }
}
